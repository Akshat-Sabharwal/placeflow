# Shared Project Context and Agent Boundaries

> **MANDATORY CONTEXT FOR EVERY CODING AGENT**
>
> Load this before the task-specific spec. This file is the cross-agent source of truth. Do not rename canonical identifiers, invent parallel APIs, move ownership between agents or add infrastructure outside this specification without an explicit contract change.

---

# 1. Product in one sentence

A minimal campus-placement operations web app in which **placement coordinators publish and manage placement drives**, while **students maintain a placement profile/resume, discover eligible drives, apply, and track outcomes**.

Exactly two application roles exist:

```text
student
coordinator
```

No company portal and no general admin UI are in hackathon scope.

---

# 2. End-to-end workflow

```text
Coordinator OAuth login
        ↓
Create / publish drive
        ↓
PostgreSQL commit
        ├────────→ students discover it through HTTP polling
        └────────→ DB Webhook → Edge Function → Web Push
                                      ↓
Student sees/open drive
        ↓
Eligibility is displayed
        ↓
Student applies with an existing private resume
        ↓
Application INSERT
        ↓
Coordinator applicant-list polling sees it
        ↓
Coordinator views authorized signed resume URL
        ↓
Coordinator changes application status
        ↓
Application UPDATE
        ├────────→ student's application polling sees it
        └────────→ optional persistent notification + Web Push
```

Push and polling reveal persisted state; neither owns workflow state.

---

# 3. Product goals

The finished hackathon application must demonstrate:

1. OAuth-only authentication.
2. Trusted student/coordinator authorization.
3. Application-owned placement profile.
4. Private PDF document storage.
5. Drive creation/edit/publish workflow.
6. Simple, explainable eligibility checks.
7. Student application submission.
8. Coordinator applicant management.
9. Student application-status tracking.
10. Near-live collaboration through query polling.
11. Browser push for important events.
12. Correct server validation, RLS, database constraints and secret handling.
13. Clean Vercel + Supabase deployment.

---

# 4. Explicit non-goals

Do **not** add:

- Supabase Realtime
- custom WebSocket / Socket.IO server
- Redis
- Kafka/RabbitMQ/queues
- Express, NestJS or Fastify server
- microservices
- chat
- employer portal
- generic RBAC framework
- complex interview-round engine
- AI ranking/recommendations
- resume parsing
- attendance
- Elasticsearch
- analytics warehouse
- email campaign suite
- unrestricted LinkedIn CV/profile ingestion

This is a workflow product, not an infrastructure demonstration.

---

# 5. Canonical stack

## Application

```text
Next.js App Router
TypeScript
React
Chakra UI
Tailwind CSS (minor layout/spacing only)
TanStack Query
Zod
```

## Platform

```text
Vercel
Supabase Auth
Supabase PostgreSQL
Supabase Storage
Supabase Database Webhooks
Supabase Edge Functions
Web Push API
Service Worker
```

## OAuth providers

Display/order:

```text
1. LinkedIn OIDC   ← preferred
2. Google
3. GitHub
```

Supabase provider identifier:

```text
linkedin_oidc
```

Never use deprecated `linkedin`.

---

# 6. Current-platform baseline

The code should follow current conventions rather than older Supabase/Next.js tutorials.

Canonical assumptions:

- Node.js 22+ for the project toolchain.
- `@supabase/ssr` for cookie-based Next.js SSR authentication.
- Supabase **publishable** key for browser/request-scoped clients.
- Supabase **secret** key only in trusted server code where the protected operation genuinely requires it.
- root `proxy.ts` for current Next.js session-refresh integration.
- verified server identity via `supabase.auth.getClaims()` (or current verified equivalent), not authorization based solely on `getSession()`.
- fresh server Supabase client per request; never keep a user-scoped client in module-global state.
- authenticated responses are dynamic/private; never ISR-cache a user session response.
- polling GETs are `private, no-store`.
- explicit table grants/Data API exposure; do not assume every new public table is automatically exposed.
- RLS enabled for all exposed public tables.

---

# 7. System laws

## 7.1 PostgreSQL is authoritative

Authoritative data:

```text
profiles
roles
drives
applications
document metadata
notifications
push subscriptions
```

Browser cache, UI state, push payload and OAuth claims are not placement workflow truth.

## 7.2 Authentication != authorization

OAuth answers identity.

Coordinator authority comes only from:

```text
public.user_roles
```

There is **no** editable `profiles.role`.

## 7.3 Never trust user-editable metadata for role

Forbidden role sources:

```text
request body
query string
profiles.role
OAuth display profile
auth user_metadata
provider name
client-side route
```

## 7.4 Protected workflow mutations go through Route Handlers

The browser may do UX validation; the server repeats authoritative validation.

Especially:

```text
create/edit drive
apply
change application status
register/delete document metadata
issue coordinator document URL
register push endpoint
```

## 7.5 Resume bucket is private

Canonical bucket:

```text
student-documents
```

Object path:

```text
{userId}/{documentType}/{uuid}.pdf
```

No public resume URLs.

## 7.6 Upload bytes go browser → Supabase Storage

Do not proxy PDF bytes through Vercel.

Flow:

```text
browser direct Storage upload under Storage RLS
        ↓
POST document metadata to Next.js API
```

## 7.7 No WebSockets

Near-live screens use polling.

No Realtime library/subscription should appear in code.

## 7.8 Push is advisory

A push may fail or be disabled. Persistent notification/application/drive state still works.

## 7.9 Webhook processing is idempotent

Retries must not create duplicate logical notifications.

Canonical DB uniqueness:

```text
UNIQUE(user_id, event_key)
```

---

# 8. Canonical roles

Database enum:

```text
student
coordinator
```

Canonical sealed role table:

```text
public.user_roles
```

New auth user:

```text
student
```

by default.

Coordinator promotion happens through trusted developer/admin SQL/admin tooling, not an application page.

This avoids stale/unsafe `profiles.role` or user metadata.

---

# 9. Canonical drive states

```text
draft
published
registration_closed
ongoing
completed
cancelled
```

Allowed state graph:

```text
draft
 ├─→ published
 └─→ cancelled

published
 ├─→ registration_closed
 └─→ cancelled

registration_closed
 ├─→ ongoing
 └─→ cancelled

ongoing
 ├─→ completed
 └─→ cancelled

completed  terminal
cancelled  terminal
```

Application is accepted only if:

```text
drive.status == published
AND now < registration_deadline
```

---

# 10. Canonical application states

```text
applied
shortlisted
selected
rejected
```

Allowed graph:

```text
applied
 ├─→ shortlisted
 └─→ rejected

shortlisted
 ├─→ selected
 └─→ rejected

selected terminal
rejected terminal
```

---

# 11. Eligibility contract

A student may apply only when all are true:

1. authenticated
2. role = student
3. onboarding complete
4. drive exists
5. drive status = `published`
6. current server time is before registration deadline
7. branch in `eligible_branches`
8. graduation year in `eligible_years`
9. CGPA >= `minimum_cgpa`
10. backlogs <= `maximum_backlogs`
11. selected document exists
12. document belongs to requester
13. document type = `resume`
14. no existing application for same student+drive

Client may display eligibility, but Apply recomputes it on the server.

---

# 12. Canonical persistence model

```text
auth.users            Supabase-managed
auth.identities       Supabase-managed

public.profiles
public.user_roles
public.drives
public.applications
public.documents
public.notifications
public.push_subscriptions

storage bucket:
student-documents
```

Relations:

```text
auth.users 1 ── 1 profiles
auth.users 1 ── 1 user_roles

coordinator 1 ── N drives

student N ── M drives
          through applications

student 1 ── N documents
user    1 ── N notifications
user    1 ── N push_subscriptions
```

Structural uniqueness:

```text
profiles.roll_number                 unique when non-null
applications(student_id, drive_id)   unique
documents.storage_path               unique
notifications(user_id,event_key)     unique
push_subscriptions.endpoint          unique
```

---

# 13. Canonical API routes

These names are frozen.

## Profile

```text
GET    /api/profile
PATCH  /api/profile
```

## Drives

```text
GET    /api/drives
GET    /api/drives/{id}
POST   /api/drives
PATCH  /api/drives/{id}
```

## Applications

```text
POST   /api/drives/{id}/apply
GET    /api/applications/me
GET    /api/drives/{id}/applications
PATCH  /api/applications/{id}/status
```

## Documents

```text
GET    /api/documents
POST   /api/documents/metadata
DELETE /api/documents/{id}
GET    /api/documents/{id}/url
```

There is deliberately **no file-bytes upload REST endpoint**.

## Notifications

```text
GET    /api/notifications
PATCH  /api/notifications/{id}/read
```

## Push

```text
POST   /api/push/subscriptions
DELETE /api/push/subscriptions
```

---

# 14. Canonical API envelopes

## Success

```json
{
  "data": {}
}
```

Collection:

```json
{
  "data": [],
  "meta": {
    "nextCursor": null
  }
}
```

## Error

```json
{
  "error": {
    "code": "INELIGIBLE",
    "message": "You do not satisfy this drive's eligibility requirements.",
    "details": {}
  }
}
```

Canonical error codes:

```text
UNAUTHENTICATED
FORBIDDEN
VALIDATION_ERROR
NOT_FOUND
CONFLICT
PROFILE_INCOMPLETE
INELIGIBLE
DRIVE_CLOSED
DEADLINE_PASSED
DUPLICATE_APPLICATION
INVALID_STATUS_TRANSITION
DOCUMENT_IN_USE
STORAGE_OBJECT_MISSING
INTERNAL_ERROR
```

Do not invent endpoint-specific envelope shapes.

---

# 15. Canonical query keys

TanStack Query:

```ts
['viewer']
['profile']
['drives', filters]
['drive', driveId]
['applications', 'me', filters]
['drive-applications', driveId, filters]
['documents']
['notifications', filters]
```

Polling:

| Data | Interval |
|---|---:|
| student drive feed | ~15s |
| active drive detail | ~15s if useful |
| student applications | ~10s |
| coordinator applicant list | ~5s |
| profile | none |
| documents | none |
| coordinator edit form | none |
| notifications | optional 15–30s |

Do not enable interval polling in background tabs.

Refetch-on-focus/reconnect is desirable.

After successful local mutations, invalidate relevant query immediately.

---

# 16. Canonical push payload

```ts
type PushPayload = {
  type: 'drive_published' | 'drive_updated' | 'application_status_changed'
  title: string
  body: string
  url: string
  entityId: string
  eventKey: string
}
```

Example:

```json
{
  "type": "drive_published",
  "title": "New placement drive",
  "body": "Microsoft — Software Engineer",
  "url": "/student/drives/DRIVE_UUID",
  "entityId": "DRIVE_UUID",
  "eventKey": "drive:DRIVE_UUID:published:EVENT_VERSION"
}
```

Never include resume contents, CGPA, private keys or sensitive student data.

---

# 17. LinkedIn boundary

LinkedIn OIDC is preferred for professional-context login.

But the application must **not depend on unrestricted LinkedIn full-profile access**.

Safe identity/bootstrap data may include:

```text
name
email
profile image
provider identity
```

Application-owned placement data:

```text
roll number
branch
graduation year
CGPA
backlogs
resume
optional LinkedIn URL
optional GitHub URL
```

Do not build normal hackathon functionality around partner-only/full LinkedIn APIs.

---

# 18. Student journey

```text
/login
  ↓ OAuth
/auth/callback
  ↓
/post-auth
  ↓
if profile incomplete
/student/onboarding
  ↓
/student
```

Student navigation:

```text
Home
Drives
Applications
Documents
Profile
```

Plus notification bell and sign out.

Core sequence:

```text
onboard
→ upload resume
→ enable notifications optionally
→ discover drive
→ inspect eligibility
→ apply
→ track status
```

---

# 19. Coordinator journey

```text
/login
  ↓ OAuth
/auth/callback
  ↓
/post-auth
  ↓ trusted role
/coordinator
```

Coordinator navigation:

```text
Drives
Create Drive
```

Drive management:

```text
Overview
Applicants
Edit
```

Core sequence:

```text
create draft/publish
→ applicant list
→ view authorized resume
→ shortlist/select/reject
→ close/cancel/complete drive
```

---

# 20. Agent file ownership

No two agents own the same paths.

## Agent A — Database

Owns:

```text
supabase/migrations/**
supabase/seed.sql
lib/types/database.types.ts
```

Does not create APIs/pages/auth/Edge code.

## Agent B — Backend + async

Owns:

```text
app/api/**
lib/contracts/**
lib/domain/**
lib/server/**
supabase/functions/send-push/**
```

Does not alter migrations, OAuth/session files, feature pages or Service Worker.

## Agent C — OAuth/session

Owns:

```text
app/login/**
app/auth/callback/**
app/auth/auth-code-error/**
app/post-auth/**
lib/supabase/client.ts
lib/supabase/server.ts
lib/supabase/proxy.ts
lib/auth/**
proxy.ts
```

Does not create feature APIs/pages/Edge logic.

## Agent D — UI/client

Owns:

```text
app/student/**
app/coordinator/**
components/**
providers/**
lib/api-client/**
lib/queries/**
lib/ui/**
public/sw.js
```

Does not create API routes/migrations/OAuth callback/domain server rules.

---

# 21. Shared-code contracts

## Database types

Agent A generates:

```text
lib/types/database.types.ts
```

Never hand-edit.

## App/API contracts

Agent B creates:

```text
lib/contracts/api.ts
lib/contracts/domain.ts
lib/contracts/schemas.ts
lib/contracts/push.ts
```

Agent D imports them and does not fork definitions.

## Supabase clients/auth guards

Agent C owns:

```text
lib/supabase/**
lib/auth/**
```

Agents B/D import them and never create duplicate client factories.

---

# 22. Folder ownership map

```text
app/
├── login/                Agent C
├── auth/                 Agent C
├── post-auth/            Agent C
├── student/              Agent D
├── coordinator/          Agent D
└── api/                  Agent B

components/               Agent D
providers/                Agent D

lib/
├── api-client/           Agent D
├── queries/              Agent D
├── ui/                   Agent D
├── contracts/            Agent B
├── domain/               Agent B
├── server/               Agent B
├── auth/                 Agent C
├── supabase/             Agent C
└── types/
    └── database.types.ts Agent A

public/sw.js              Agent D

supabase/
├── migrations/           Agent A
├── seed.sql              Agent A
└── functions/send-push/  Agent B

proxy.ts                  Agent C
```

A merge conflict across two agents in these paths is evidence that an ownership boundary was crossed.

---

# 23. Backend trust model

Use two concepts, not one accidental all-powerful client.

## Request-scoped user client

Owned by Agent C, using `@supabase/ssr` + publishable key + session cookies.

Use for:

- verified claims
- RLS-protected relational reads
- user-context lookups such as own role/profile

The ordinary authenticated Data API is intentionally **read-only for application relational tables** in this project.

## Privileged server client

Created only inside trusted Next.js/Edge code.

Environment:

```text
SUPABASE_SECRET_KEY
```

All relational mutations cross the Route Handler trust boundary and use the privileged writer **only after** verified authentication, role/ownership checks, Zod validation and domain validation.

This includes:

- profile mutation
- drive create/edit/status mutation
- guarded application INSERT
- coordinator application-status mutation
- document metadata mutation
- notification read mutation
- push-subscription mutation
- signed URL creation
- async notification fan-out

The deliberate exception is **binary Storage upload**: the authenticated browser uploads a new UUID-named PDF directly to its own Storage prefix under Storage RLS.

A secret key is never authorization logic. Code must authenticate/authorize first.

---

# 24. Storage contract

Private bucket:

```text
student-documents
```

Supported hackathon document:

```text
PDF
maximum 10 MiB
```

Upload path:

```text
{userId}/{type}/{uuid}.pdf
```

Student upload:

```text
browser Supabase client
→ private Storage
→ POST /api/documents/metadata
```

Student deletion:

```text
DELETE /api/documents/{id}
```

because server must first check whether an application references it.

Coordinator resume:

```text
GET /api/documents/{id}/url
```

returns a short-lived signed URL only after authorization.

---

# 25. Notification pipeline

DB Webhooks watch broad events:

```text
drives INSERT/UPDATE
applications UPDATE
```

The Edge Function filters meaningful transitions.

Notify on:

- drive created as published
- draft → published
- important published-drive change if implemented
- application status actually changes to shortlisted/selected/rejected

Ignore:

- draft creation
- no-op updates
- cosmetic drive edits by default
- repeated webhook retry already represented by same event key

---

# 26. Quality requirements

Each agent must:

1. preserve canonical names
2. stay within owned paths
3. type-check/lint owned code
4. test pure business rules
5. avoid TODO placeholders in core paths
6. produce clear error handling
7. keep secrets out of browser code
8. not add Realtime/socket infrastructure
9. not broaden scope
10. report any required cross-agent change instead of silently applying it

---

# 27. Contract-change protocol

If an agent finds a genuine missing cross-agent contract:

```text
do not rename/fix it locally
```

Instead produce a note:

```markdown
# CONTRACT_CHANGE_REQUEST

Current contract:
Required change:
Reason:
Agents/files affected:
Backward-compatible: yes/no
```

The integration owner decides.

For the specified hackathon scope, this should rarely be necessary.

---

# 28. Full-system acceptance test

The integrated project passes when:

1. LinkedIn OIDC login succeeds.
2. New OAuth user gets student role.
3. Student completes onboarding.
4. Student uploads a private PDF directly to Storage.
5. Document metadata is stored.
6. A trusted role row promotes another user to coordinator.
7. Coordinator creates/publishes a drive.
8. Student drive feed discovers it on ~15s polling.
9. Ineligible direct/bypassed Apply request still fails server-side.
10. Eligible Apply succeeds.
11. Duplicate Apply fails race-safely.
12. Coordinator applicant list discovers new application on ~5s polling.
13. Coordinator can open only an authorized applicant resume via temporary signed URL.
14. Coordinator shortlists application.
15. Student sees status on ~10s polling.
16. Important event creates persistent notification.
17. Push works when enabled, but the workflow still works when it is disabled.
18. No WebSocket/Realtime connection is necessary.
