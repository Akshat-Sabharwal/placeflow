# Database Migrations and Schema — Code Generation Specification

> Load `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md` first.
>
> **Owned paths only:** `supabase/migrations/**`, `supabase/seed.sql`, generated `lib/types/database.types.ts`.
>
> Do not implement Next.js APIs, OAuth/session code, feature pages, Edge Function application code or query hooks.

---

# 1. Mission

Implement a reproducible Supabase/PostgreSQL schema that all other agents can use without renaming or patching.

The database owns:

- persistence structure
- relational integrity
- low-level authorization through RLS
- explicit Data API grants
- private Storage object boundaries
- useful polling indexes
- auth-user bootstrap
- race-safe uniqueness

The database does **not** need to reimplement the entire TypeScript business layer in SQL.

Sensitive writes that need multi-table workflow validation are intentionally performed through trusted Next.js Route Handlers.

---

# 2. Migration discipline

Use the installed Supabase CLI. Before relying on syntax:

```bash
npx supabase migration --help
npx supabase migration new --help
```

Create logical migrations in this order:

```text
01_core_types_and_tables
02_auth_bootstrap
03_grants_and_rls
04_storage_bucket_and_policies
05_indexes_and_database_guards
```

Let the CLI generate timestamp prefixes.

Do not create migrations manually in the Dashboard and forget to represent them in source control.

---

# 3. Extension

Use:

```sql
create extension if not exists citext;
```

Do not specify an extension version.

`citext` is useful for stored email snapshots/admin lookup.

---

# 4. Exact enums

```sql
create type public.app_role as enum (
  'student',
  'coordinator'
);

create type public.drive_status as enum (
  'draft',
  'published',
  'registration_closed',
  'ongoing',
  'completed',
  'cancelled'
);

create type public.application_status as enum (
  'applied',
  'shortlisted',
  'selected',
  'rejected'
);

create type public.document_type as enum (
  'resume',
  'marksheet',
  'other'
);
```

Keep notification `type` as text to avoid an enum migration every time notification vocabulary grows.

---

# 5. `public.profiles`

Purpose:

1:1 application profile for `auth.users`.

No trusted role column.

Target shape:

```sql
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,

  email citext not null,
  full_name text,
  avatar_url text,
  primary_provider text,

  roll_number text unique,
  branch text,
  graduation_year integer,
  cgpa numeric(4,2),
  backlogs integer,

  linkedin_url text,
  github_url text,

  onboarding_completed_at timestamptz,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint profiles_full_name_length
    check (full_name is null or char_length(full_name) between 1 and 120),

  constraint profiles_roll_number_length
    check (roll_number is null or char_length(roll_number) between 1 and 64),

  constraint profiles_graduation_year_range
    check (
      graduation_year is null
      or graduation_year between 2000 and 2100
    ),

  constraint profiles_cgpa_range
    check (
      cgpa is null
      or (cgpa >= 0 and cgpa <= 10)
    ),

  constraint profiles_backlogs_range
    check (
      backlogs is null
      or (backlogs >= 0 and backlogs <= 99)
    )
);
```

Notes:

- academic fields remain nullable because coordinators do not require them
- a student is considered ready to apply only when onboarding is complete
- email/name/avatar/provider are convenient snapshots
- Auth remains identity authority
- OAuth metadata may seed cosmetic fields only

---

# 6. `public.user_roles`

Trusted authorization table:

```sql
create table public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'student',
  granted_at timestamptz not null default now()
);
```

Rules:

- every new user starts as student
- application user may SELECT own role
- application user may never mutate roles
- developer/admin promotes coordinators
- no role-management feature in the application

This table replaces unsafe `profiles.role`.

---

# 7. `public.drives`

```sql
create table public.drives (
  id uuid primary key default gen_random_uuid(),

  created_by uuid not null references public.profiles(id) on delete restrict,

  company_name text not null,
  job_role text not null,
  description text not null default '',
  location text,
  package_text text,

  eligible_branches text[] not null,
  eligible_years integer[] not null,
  minimum_cgpa numeric(4,2) not null default 0,
  maximum_backlogs integer not null default 99,

  registration_deadline timestamptz not null,
  drive_date timestamptz,

  status public.drive_status not null default 'draft',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint drives_company_name_length
    check (char_length(company_name) between 1 and 160),

  constraint drives_job_role_length
    check (char_length(job_role) between 1 and 160),

  constraint drives_eligible_branches_nonempty
    check (cardinality(eligible_branches) > 0),

  constraint drives_eligible_years_nonempty
    check (cardinality(eligible_years) > 0),

  constraint drives_minimum_cgpa_range
    check (minimum_cgpa >= 0 and minimum_cgpa <= 10),

  constraint drives_maximum_backlogs_range
    check (maximum_backlogs >= 0 and maximum_backlogs <= 99)
);
```

Do not encode the full transition graph in a complicated SQL trigger.

The backend domain layer owns state-transition semantics.

The DB owns structural type/range sanity.

---

# 8. `public.documents`

Metadata only.

```sql
create table public.documents (
  id uuid primary key default gen_random_uuid(),

  student_id uuid not null references public.profiles(id) on delete cascade,

  type public.document_type not null,
  storage_path text not null unique,
  original_name text not null,
  mime_type text not null,
  size_bytes bigint not null,

  uploaded_at timestamptz not null default now(),

  constraint documents_storage_path_length
    check (char_length(storage_path) between 1 and 500),

  constraint documents_original_name_length
    check (char_length(original_name) between 1 and 255),

  constraint documents_size_positive
    check (size_bytes > 0 and size_bytes <= 10485760)
);
```

Canonical file size ceiling:

```text
10 MiB
```

Canonical resume format:

```text
application/pdf
```

The bucket and backend independently enforce these expectations.

---

# 9. `public.applications`

```sql
create table public.applications (
  id uuid primary key default gen_random_uuid(),

  student_id uuid not null references public.profiles(id) on delete restrict,
  drive_id uuid not null references public.drives(id) on delete restrict,
  resume_document_id uuid not null references public.documents(id) on delete restrict,

  status public.application_status not null default 'applied',

  applied_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint applications_one_per_student_drive
    unique (student_id, drive_id)
);
```

Important:

Do **not** give ordinary authenticated users direct INSERT privilege.

The Apply Route Handler validates:

```text
identity
role
onboarding
drive state
deadline
branch/year/CGPA/backlogs
resume ownership/type
existing application
```

Then performs the protected insert.

The unique constraint closes the race window if two Apply requests arrive together.

---

# 10. `public.notifications`

Persistent in-app history + webhook idempotency anchor.

```sql
create table public.notifications (
  id uuid primary key default gen_random_uuid(),

  user_id uuid not null references public.profiles(id) on delete cascade,

  event_key text not null,
  type text not null,

  title text not null,
  body text not null,
  url text not null,

  drive_id uuid references public.drives(id) on delete cascade,
  application_id uuid references public.applications(id) on delete cascade,

  read_at timestamptz,
  created_at timestamptz not null default now(),

  constraint notifications_event_key_length
    check (char_length(event_key) between 1 and 300),

  constraint notifications_user_event_unique
    unique (user_id, event_key)
);
```

Do **not** make `event_key` globally unique because one drive-published event legitimately creates a row for many users.

---

# 11. `public.push_subscriptions`

```sql
create table public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),

  user_id uuid not null references public.profiles(id) on delete cascade,

  endpoint text not null unique,
  p256dh text not null,
  auth text not null,

  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),

  constraint push_endpoint_length
    check (char_length(endpoint) between 10 and 3000)
);
```

Never surface these keys in broad API DTOs.

---

# 12. Auth bootstrap schema

Use a non-exposed helper schema:

```sql
create schema if not exists private;
```

Create:

```text
private.handle_new_auth_user()
```

as trigger function.

It must insert:

```text
profiles
user_roles(role='student')
```

A safe shape:

```sql
create or replace function private.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (
    id,
    email,
    full_name,
    avatar_url,
    primary_provider
  )
  values (
    new.id,
    new.email,
    coalesce(
      new.raw_user_meta_data ->> 'full_name',
      new.raw_user_meta_data ->> 'name'
    ),
    coalesce(
      new.raw_user_meta_data ->> 'avatar_url',
      new.raw_user_meta_data ->> 'picture'
    ),
    new.raw_app_meta_data ->> 'provider'
  );

  insert into public.user_roles (user_id, role)
  values (new.id, 'student');

  return new;
end;
$$;
```

Then:

```text
REVOKE EXECUTE from PUBLIC/anon/authenticated
```

and create the `AFTER INSERT ON auth.users` trigger.

Why private schema:

A SECURITY DEFINER function bypasses ordinary caller privilege. It must not accidentally become a public RPC.

OAuth metadata is permitted for display fields.

Never read authorization role from `raw_user_meta_data`.

---

# 13. Updated timestamps

Create a simple trigger function:

```text
private.set_updated_at()
```

It can be ordinary PL/pgSQL without SECURITY DEFINER.

Set:

```text
NEW.updated_at = now()
```

on UPDATE for:

```text
profiles
drives
applications
```

Clients do not authoritatively set these timestamps.

---

# 14. Explicit grants

Current projects should not rely on historical automatic Data API exposure.

The canonical application architecture deliberately makes **ordinary relational Data API access read-only**. The browser never performs relational mutations directly; Next.js Route Handlers do so after business authorization/validation.

`anon`: no application-table access.

Grant `authenticated` only the SELECT privileges needed by request-scoped/RLS reads:

```text
profiles             SELECT
user_roles           SELECT
drives               SELECT
applications         SELECT
documents            SELECT
notifications        SELECT
push_subscriptions   no direct privilege required
```

Do **not** grant ordinary authenticated:

```text
INSERT
UPDATE
DELETE
```

on these application tables.

Consequences:

- a student cannot bypass `PATCH /api/profile`
- a coordinator cannot bypass drive transition validation with direct PostgREST UPDATE
- a student cannot bypass Apply
- a coordinator cannot mutate application identity/resume/status outside the API
- a user cannot rewrite notification title/body directly
- push endpoints cannot be manipulated directly

Trusted Route Handlers use the server-only privileged Supabase client after authorization.

This is deliberate defense-in-depth, not an accident.

The only direct browser mutation in the whole project is the Storage object upload governed separately by `storage.objects` RLS.

---

# 15. Coordinator predicate

For RLS checks, use an understandable existence test:

```sql
exists (
  select 1
  from public.user_roles ur
  where ur.user_id = (select auth.uid())
    and ur.role = 'coordinator'
)
```

`user_roles` itself should permit a user to read only their own row.

Avoid creating a public SECURITY DEFINER `is_admin()` shortcut unless a real measured RLS problem requires it and current Supabase guidance is rechecked.

---

# 16. RLS — `profiles`

Enable RLS.

SELECT policies:

## own profile

```text
id = auth.uid()
```

## coordinator applicant/profile visibility

Current user has coordinator role.

There is no ordinary authenticated UPDATE grant. Profile writes go through `PATCH /api/profile`, whose trusted writer sets the row only after verifying the requester and input.

This prevents direct Data API mutation of identity snapshots or onboarding state.

---

# 17. RLS — `user_roles`

Enable RLS.

Only:

```text
SELECT own row
```

No authenticated insert/update/delete policy.

This is the authorization seal.

---

# 18. RLS — `drives`

Enable RLS.

Canonical shared-placement-cell model:

```text
all coordinators may manage all placement drives through the trusted API
```

SELECT policies:

## students/general authenticated

May read non-draft drives.

```text
published
registration_closed
ongoing
completed
cancelled
```

## coordinator

May read all drives including drafts.

There is no direct authenticated INSERT/UPDATE/DELETE grant.

Drive creation/edit/status transitions go through trusted Next.js Route Handlers and privileged server writes.

This prevents a coordinator from bypassing the canonical drive transition graph or rewriting `created_by` through direct PostgREST calls.

---

# 19. RLS — `applications`

Enable RLS.

SELECT policies:

## student

```text
student_id = auth.uid()
```

## coordinator

```text
current trusted role = coordinator
```

No ordinary authenticated INSERT/UPDATE/DELETE grants.

Therefore:

- students cannot bypass Apply
- coordinators cannot directly rewrite student_id/drive_id/resume_document_id/status
- all application mutation flows cross the Next.js API trust boundary

---

# 20. RLS — `documents`

Enable RLS.

Normal student SELECT:

```text
student_id = auth.uid()
```

No direct metadata insert/update/delete grant.

Coordinator direct document-table access is intentionally not broadly exposed.

Signed URL endpoint uses an explicitly authorized privileged lookup.

---

# 21. RLS — `notifications`

Enable RLS.

SELECT policy:

```text
user_id = auth.uid()
```

There is no direct authenticated UPDATE/INSERT/DELETE grant.

`PATCH /api/notifications/{id}/read` performs the narrow read-state mutation after verifying ownership.

This prevents direct callers from rewriting notification title/body/url/event identity.

---

# 22. RLS — `push_subscriptions`

Enable RLS even if Data API grants are withheld.

If own-row SELECT is later required:

```text
user_id = auth.uid()
```

Never allow one user to enumerate another user's endpoint/key material.

---

# 23. Private Storage bucket

Canonical bucket:

```text
student-documents
```

Create private bucket with:

```text
public = false
file size max = 10 MiB
allowed MIME = application/pdf
```

No permanent public URL.

Canonical object key:

```text
{auth.uid()}/{documentType}/{uuid}.pdf
```

Never use untrusted original filename as Storage key.

---

# 24. Storage object policies

On `storage.objects`, permit authenticated users only when:

```text
bucket_id = 'student-documents'
AND first folder segment = auth.uid()::text
```

Canonical browser permissions:

## SELECT own objects

Allows a student to view/download their own uploaded documents.

## INSERT into own namespace

Allows a student to upload a **new UUID-named object**.

Do **not** grant ordinary authenticated Storage UPDATE or DELETE.

Why immutability matters:

An application records the exact `resume_document_id`. If a student could overwrite or delete that underlying object directly after applying, the historical application could silently point at altered/missing bytes.

Therefore:

```text
browser upload = INSERT new immutable object
replace resume = upload a new UUID object
delete resume = DELETE /api/documents/{id}
```

The server delete endpoint checks application references and uses privileged Storage access only when deletion is allowed.

Do not use Storage `upsert:true` in the browser.

---

# 25. Polling-aligned indexes

Create only useful indexes.

## drives

```text
(status, registration_deadline)
(updated_at desc)
```

## applications

```text
(student_id, updated_at desc)
(drive_id, applied_at desc)
(drive_id, status, applied_at desc)
```

The unique constraint already indexes:

```text
(student_id, drive_id)
```

## documents

```text
(student_id, uploaded_at desc)
```

## notifications

```text
(user_id, created_at desc)
(user_id, read_at, created_at desc)
```

## push subscriptions

```text
(user_id)
```

These match the repeated query paths. Do not create speculative indexes for every column.

---

# 26. Seed strategy

Do not fake a production-like `auth.users` database manually unless current local Supabase auth testing specifically requires it.

Recommended:

1. real test users sign in once
2. bootstrap trigger creates profile + student role
3. developer promotes one account through trusted SQL
4. optional demo drives are inserted using that real coordinator id

Coordinator promotion:

```sql
update public.user_roles
set role = 'coordinator',
    granted_at = now()
where user_id = (
  select id
  from public.profiles
  where email = 'coordinator@example.edu'
);
```

No in-app promotion endpoint.

---

# 27. Type generation

After migrations work:

```bash
npx supabase gen types --help
```

Use the current CLI-supported local/project form to generate:

```text
lib/types/database.types.ts
```

Do not hand-edit generated types.

Regenerate after schema changes.

---

# 28. Database verification

The agent is not done until it proves:

## Integrity

- invalid CGPA rejected
- negative backlog rejected
- empty eligibility arrays rejected
- duplicate student+drive application rejected
- duplicate `(user,event_key)` notification rejected
- invalid FK references rejected

## Roles

As student:

- can read own role
- cannot read someone else's role
- cannot update role

## Profiles

- student reads own profile
- coordinator can read needed applicant profiles
- ordinary authenticated direct profile UPDATE is denied
- `PATCH /api/profile` remains the write path

## Drives

- draft hidden from student
- published/non-draft visible as specified
- coordinator can SELECT drafts
- ordinary authenticated INSERT/UPDATE/DELETE is denied even for coordinator
- trusted Route Handlers remain the only drive write path

## Applications

- student sees own only
- coordinator sees authorized applicant data
- ordinary authenticated INSERT/UPDATE/DELETE is denied
- Apply/status mutations only work through trusted APIs

## Storage

- own-prefix INSERT works
- foreign-prefix INSERT fails
- own SELECT works
- foreign SELECT fails
- ordinary browser UPDATE/DELETE fails
- bucket is private

## Notifications

- own only
- user cannot create fake persistent notification

Run current Supabase advisors/security checks available in the installed tooling and resolve material warnings.

---

# 29. Deliverables

Only:

```text
supabase/migrations/<generated>_core_types_and_tables.sql
supabase/migrations/<generated>_auth_bootstrap.sql
supabase/migrations/<generated>_grants_and_rls.sql
supabase/migrations/<generated>_storage_bucket_and_policies.sql
supabase/migrations/<generated>_indexes_and_database_guards.sql
supabase/seed.sql
lib/types/database.types.ts
```

Handoff report:

```text
migrations clean: yes/no
RLS verified: yes/no
Storage policies verified: yes/no
type generation refreshed: yes/no
advisor warnings remaining: ...
```
