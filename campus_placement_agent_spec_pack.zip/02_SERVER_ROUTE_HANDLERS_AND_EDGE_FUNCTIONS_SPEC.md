# Next.js Route Handlers and Supabase Edge Functions — Code Generation Specification

> Load `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md` first.
>
> **Owned paths only:** `app/api/**`, `lib/contracts/**`, `lib/domain/**`, `lib/server/**`, `supabase/functions/send-push/**`.
>
> Do not alter migrations, OAuth/session files, feature UI pages or `public/sw.js`.

---

# 1. Mission

Implement the project's trusted HTTP/workflow boundary and asynchronous notification worker.

This agent owns:

- API/DTO contract types
- shared Zod request schemas
- pure eligibility/status-transition functions
- Next.js Route Handlers
- authorization at business-operation boundaries
- narrow privileged Supabase operations
- signed document URL gate
- webhook interpretation
- idempotent notification creation
- Supabase Edge Function Web Push fan-out

No always-on custom server exists.

---

# 2. Runtime model

```text
Browser
  ↓ ordinary HTTPS
Next.js Route Handler on Vercel
  ↓
Supabase Auth/Postgres/Storage
```

Async:

```text
DB commit
  ↓
Database Webhook
  ↓
Supabase Edge Function
  ↓
notification row + Web Push
```

Forbidden additions:

```text
Express
NestJS
Fastify
Socket.IO
Supabase Realtime
Redis
queue/broker
```

---

# 3. Supabase client model

Import factories from Agent C.

## Request-scoped user client

Uses:

```text
@supabase/ssr
publishable key
request cookies
```

Use for:

- verified identity
- trusted role lookup
- RLS-protected relational reads

Create per request.

The ordinary authenticated relational Data API is intentionally read-only.

## Privileged client

Uses server-only:

```text
SUPABASE_SECRET_KEY
```

Use for **all relational mutations**, but only after the handler has already authenticated, authorized, parsed and domain-validated the request.

Canonical writes include:

- profile update
- drive INSERT/UPDATE
- guarded application INSERT
- application-status UPDATE
- document metadata INSERT/DELETE
- notification `read_at` update
- push subscription UPSERT/DELETE
- Edge Function notification writes

Also use privileged Storage access for:

- coordinator signed URL creation
- server-approved document deletion

A privileged client does not authorize a user. The handler authenticates and checks role/ownership **first**.

---

# 4. Verified identity

Every protected handler:

1. create request-scoped Supabase client
2. call `auth.getClaims()` or current verified equivalent
3. require `claims.sub`
4. derive actor `userId` only from claims

Never trust:

```text
body.userId
body.studentId
body.role
query userId
unverified getSession().user
```

---

# 5. Trusted role

Create reusable helpers under:

```text
lib/server/auth/
```

Conceptual surface:

```text
requireUser()
requireStudent()
requireCoordinator()
```

Role comes from:

```text
public.user_roles
```

Do not query role from `profiles` or user metadata.

---

# 6. Shared contracts — mandatory

Create:

```text
lib/contracts/api.ts
lib/contracts/domain.ts
lib/contracts/schemas.ts
lib/contracts/push.ts
```

The UI agent imports these exact files.

## `api.ts`

Define:

```text
ApiSuccess<T>
ApiCollection<T>
ApiErrorBody
ApiErrorCode
```

Success:

```json
{"data":{}}
```

Error:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "...",
    "details": {}
  }
}
```

## `domain.ts`

Define DTOs, not raw DB rows:

```text
ViewerDTO
ProfileDTO
DriveDTO
EligibilityDTO
ApplicationDTO
ApplicantDTO
DocumentDTO
NotificationDTO
```

## `schemas.ts`

Zod:

```text
updateProfileSchema
createDriveSchema
updateDriveSchema
applySchema
changeApplicationStatusSchema
documentMetadataSchema
pushSubscriptionSchema
deletePushSubscriptionSchema
```

## `push.ts`

```ts
type PushPayload = {
  type: 'drive_published' | 'drive_updated' | 'application_status_changed'
  title: string
  body: string
  url: string
  entityId: string
  eventKey: string
}
```

---

# 7. One API response helper

Create reusable helpers:

```text
apiData(...)
apiError(...)
```

Canonical HTTP mapping:

```text
401 UNAUTHENTICATED
403 FORBIDDEN
400 VALIDATION_ERROR
404 NOT_FOUND
409 CONFLICT / DUPLICATE_APPLICATION / INVALID_STATUS_TRANSITION
410 DRIVE_CLOSED / DEADLINE_PASSED
500 INTERNAL_ERROR
```

Do not invent new envelope shapes per endpoint.

---

# 8. Freshness/caching

Polling must hit current data.

Every polling/authenticated GET:

```text
Cache-Control: private, no-store
```

Do not use ISR/public caching for user-specific APIs.

Do not accidentally turn a 5-second polling query into repeated CDN cache hits.

---

# 9. Pure eligibility function

Owned:

```text
lib/domain/eligibility.ts
```

Input:

```ts
student:
  onboardingCompletedAt
  branch
  graduationYear
  cgpa
  backlogs

drive:
  status
  registrationDeadline
  eligibleBranches
  eligibleYears
  minimumCgpa
  maximumBacklogs

now: Date
```

Output:

```ts
{
  eligible: boolean,
  reasons: EligibilityReason[]
}
```

Reason codes:

```text
PROFILE_INCOMPLETE
DRIVE_NOT_OPEN
DEADLINE_PASSED
BRANCH_NOT_ELIGIBLE
YEAR_NOT_ELIGIBLE
CGPA_TOO_LOW
TOO_MANY_BACKLOGS
```

Pure and unit-tested.

---

# 10. Drive state function

Owned:

```text
lib/domain/drive-status.ts
```

Allowed:

```text
draft -> published | cancelled
published -> registration_closed | cancelled
registration_closed -> ongoing | cancelled
ongoing -> completed | cancelled
completed -> none
cancelled -> none
```

No reopening terminal states.

---

# 11. Application state function

Owned:

```text
lib/domain/application-status.ts
```

Allowed:

```text
applied -> shortlisted | rejected
shortlisted -> selected | rejected
selected -> none
rejected -> none
```

Unit-test full matrix.

---

# 12. `GET /api/profile`

Actor:

Any authenticated user.

Flow:

```text
require user
→ SELECT own profiles row
→ SELECT own trusted user_roles row
→ return {profile, role}
```

This is the canonical viewer/profile bootstrap endpoint.

No push subscription secrets.

No interval polling expected.

---

# 13. `PATCH /api/profile`

Student only.

Allowed input:

```text
fullName?
rollNumber
branch
graduationYear
cgpa
backlogs
linkedinUrl?
githubUrl?
```

Never accept:

```text
id
email
role
primaryProvider
createdAt
```

Server:

1. `requireStudent`
2. Zod parse
3. normalize text/URLs
4. validate academic ranges
5. perform privileged profile UPDATE after verified student authorization
6. set `onboarding_completed_at = now()` when all required student fields are valid
7. return ProfileDTO

---

# 14. `GET /api/drives`

Student or coordinator.

Filters:

```text
status?
cursor?
```

Student:

- visible non-draft drives
- derived `EligibilityDTO`
- optionally applied flag

Coordinator:

- all coordinator-visible drives
- compact application counts if efficient

Suggested sort:

```text
open/published first
nearest registration_deadline
updated_at desc
```

Student feed polls ~15s.

No-store.

---

# 15. `GET /api/drives/{id}`

Student/coordinator.

Student response:

- drive detail
- eligibility reasons
- already-applied state
- resume metadata needed for Apply selection

Coordinator:

- drive detail
- compact counts if useful

Never include long-lived signed resume URL.

No-store.

---

# 16. `POST /api/drives`

Coordinator only.

Request:

```text
companyName
jobRole
description
location?
packageText?
eligibleBranches[]
eligibleYears[]
minimumCgpa
maximumBacklogs
registrationDeadline
driveDate?
status: draft | published
```

Only valid initial states:

```text
draft
published
```

Flow:

```text
requireCoordinator
→ Zod
→ date sanity
→ created_by = verified userId
→ privileged INSERT after authorization
→ return DriveDTO
```

Do not synchronously fan out push.

Persist first; webhook/Edge owns async notification.

---

# 17. `PATCH /api/drives/{id}`

Coordinator only.

Flow:

1. require coordinator
2. validate UUID
3. read current row
4. Zod partial
5. if status differs, validate canonical transition
6. validate any date/eligibility edits
7. perform privileged drive UPDATE
8. return DriveDTO

Webhook sees committed old/new state later.

---

# 18. `POST /api/drives/{id}/apply`

Most important guarded mutation.

Student only.

Request:

```json
{"resumeDocumentId":"uuid"}
```

Never accept `studentId`.

Exact flow:

1. verified user
2. require student role
3. validate drive UUID/body
4. load authoritative profile
5. load drive
6. run server eligibility at current server time
7. load document
8. verify:
   ```text
   document.student_id = userId
   document.type = resume
   MIME allowed
   ```
9. check duplicate for friendly error
10. protected privileged INSERT:
    ```text
    student_id = verified userId
    drive_id = path id
    resume_document_id = body id
    status = applied
    ```
11. rely on DB UNIQUE(student_id,drive_id) for race safety
12. map unique violation to `DUPLICATE_APPLICATION`
13. return ApplicationDTO

Never let browser direct-insert application.

---

# 19. `GET /api/applications/me`

Student.

Return:

```text
application id
drive id
company
job role
drive date
status
appliedAt
updatedAt
```

Sort newest/updated first.

Poll:

```text
~10s while page active
```

No-store.

---

# 20. `GET /api/drives/{id}/applications`

Coordinator.

Return ApplicantDTO:

```text
applicationId
studentId
fullName
rollNumber
branch
graduationYear
cgpa
backlogs
applicationStatus
resumeDocumentId
appliedAt
```

No signed URL.

Poll:

```text
~5s while Applicants tab active
```

No-store.

---

# 21. `PATCH /api/applications/{id}/status`

Coordinator.

Request:

```json
{"status":"shortlisted"}
```

Flow:

```text
requireCoordinator
→ load application
→ validate target enum
→ validate old→new transition
→ privileged UPDATE after authorization
→ return DTO
```

Invalid edge:

```text
409 INVALID_STATUS_TRANSITION
```

Webhook later owns notification.

---

# 22. `GET /api/documents`

Student.

Return own metadata only:

```text
id
type
originalName
mimeType
sizeBytes
uploadedAt
```

No Storage secret information.

No polling.

---

# 23. Document bytes upload — intentionally not API-owned

UI does:

```text
validate PDF/size for UX
→ path {userId}/{type}/{uuid}.pdf
→ browser Supabase Storage upload
→ POST /api/documents/metadata
```

Backend does not receive PDF bytes.

---

# 24. `POST /api/documents/metadata`

Student.

Request:

```text
storagePath
originalName
mimeType
sizeBytes
type
```

Flow:

1. require student
2. Zod
3. require Storage path first segment = verified userId
4. require expected bucket/path format
5. validate PDF/type/size rules
6. verify Storage object exists
7. protected INSERT documents metadata
8. return DocumentDTO

If metadata validation passes but the metadata INSERT fails after confirming the just-uploaded object belongs to this requester/path, perform a **best-effort privileged cleanup of that unregistered object** before returning the error.

The browser intentionally has no Storage DELETE permission.

Never accept arbitrary bucket.

---

# 25. `DELETE /api/documents/{id}`

Student.

Flow:

```text
require student
→ load doc
→ owner == user
→ check applications referencing resume_document_id
→ if referenced: 409 DOCUMENT_IN_USE
→ delete private Storage object
→ delete metadata
→ 204
```

Do not let UI bypass reference check by deleting Storage object first.

---

# 26. `GET /api/documents/{id}/url`

Coordinator only.

This is sensitive.

Flow:

1. require coordinator
2. validate document id
3. privileged load metadata
4. prove the document is referenced as an application resume
5. prove that application belongs to a placement drive coordinators may manage
6. create signed URL for fixed bucket `student-documents`
7. expire in ~60–300 seconds
8. return:
   ```json
   {
     "data":{
       "signedUrl":"...",
       "expiresAt":"..."
     }
   }
   ```

Never:

- cache
- precompute for applicant lists
- persist to DB/localStorage
- turn bucket public

---

# 27. `GET /api/notifications`

Student/user.

Filters:

```text
cursor?
unreadOnly?
```

Return own notifications newest first.

Optional polling:

```text
15–30s while app active
```

No-store.

---

# 28. `PATCH /api/notifications/{id}/read`

Owner only.

Do not accept arbitrary patch fields.

Server performs a privileged, ownership-checked update and sets:

```text
read_at = now()
```

Return updated DTO.

---

# 29. `POST /api/push/subscriptions`

Authenticated student/user.

Request mirrors PushSubscription:

```json
{
  "endpoint":"...",
  "keys":{
    "p256dh":"...",
    "auth":"..."
  }
}
```

Server:

```text
verified user
→ Zod
→ UPSERT endpoint
→ force user_id = verified userId
→ update last_seen_at
```

Never accept body userId.

---

# 30. `DELETE /api/push/subscriptions`

Request:

```json
{"endpoint":"..."}
```

Delete only if endpoint belongs to verified user.

Return 204.

---

# 31. Database Webhook contract

Webhooks are configured after deployment, not hardcoded to one project URL in migrations.

Watch:

```text
drives: INSERT, UPDATE
applications: UPDATE
```

Edge Function must receive/understand:

```text
record
old_record
event/table operation metadata
```

Broad DB events are filtered by code.

---

# 32. Meaningful webhook transitions

## Drive

Notify:

```text
INSERT status=published
```

or:

```text
old.status != published
new.status = published
```

Optional important update notification only for:

```text
registration_deadline changed
drive_date changed
location changed
status became cancelled
```

Ignore cosmetic text edits by default.

## Application

Notify only if:

```text
old.status != new.status
```

and new state:

```text
shortlisted
selected
rejected
```

---

# 33. Event-key design

Examples:

```text
drive:{driveId}:published:{updatedAt}
drive:{driveId}:cancelled:{updatedAt}
application:{applicationId}:status:{newStatus}:{updatedAt}
```

If webhook offers a stronger stable event/request identifier, use it.

The important property:

```text
same webhook retry -> same event key
real later change -> new event key
```

---

# 34. Edge Function: `send-push`

Owned:

```text
supabase/functions/send-push/**
```

Responsibilities:

```text
authenticate webhook
parse old/new event
filter meaningful transition
build event key
resolve recipients
insert persistent notification idempotently
load recipient push subscriptions
send Web Push
remove expired endpoints
log aggregates
```

Use current Deno-compatible/pinned Web Push dependency.

Commit compatible lock/config files supported by current Supabase Edge runtime.

No floating latest imports.

---

# 35. Webhook authentication

Use shared secret header:

```text
x-placement-webhook-secret
```

Secret:

```text
PLACEMENT_WEBHOOK_SECRET
```

Edge Function:

```text
missing/wrong -> 401
```

Never expose this to browser.

---

# 36. Drive-publish Edge algorithm

1. validate webhook secret
2. parse operation/record/old_record
3. detect actual publish event
4. ignore otherwise
5. query onboarding-complete students
6. filter by:
   - branch
   - year
   - CGPA
   - backlogs
7. for each student:
   - calculate event key
   - insert `notifications`
   - use conflict-safe/idempotent insert
8. only for a newly-created logical notification:
   - load that user's push endpoints
   - send PushPayload
9. permanent endpoint failure -> delete endpoint
10. temporary send failure -> log, keep endpoint
11. return 2xx if DB operation succeeded overall

At campus hackathon scale, simple batches are fine.

Do not introduce queue infrastructure.

---

# 37. Application-status Edge algorithm

1. validate webhook secret
2. compare old/new status
3. ignore unchanged/irrelevant state
4. identify application student
5. build event key
6. insert persistent notification idempotently
7. only newly-created logical event triggers sends
8. send to all valid endpoints
9. remove permanently expired endpoints
10. return success

---

# 38. Web Push payload

Must match `lib/contracts/push.ts`.

Drive:

```json
{
  "type":"drive_published",
  "title":"New placement drive",
  "body":"Microsoft — Software Engineer",
  "url":"/student/drives/UUID",
  "entityId":"UUID",
  "eventKey":"..."
}
```

Application:

```json
{
  "type":"application_status_changed",
  "title":"Application updated",
  "body":"Microsoft — Shortlisted",
  "url":"/student/applications",
  "entityId":"APPLICATION_UUID",
  "eventKey":"..."
}
```

No sensitive details.

---

# 39. Logging/security

Never log:

```text
OAuth access/refresh tokens
Supabase secret key
VAPID private key
push auth/p256dh values
signed resume URL
resume contents
```

Useful logs:

```text
route
correlation id if available
error code
event type
event key
recipient count
push sent/expired/failed counts
```

---

# 40. Required tests

## Eligibility

- eligible
- profile incomplete
- wrong branch
- wrong year
- CGPA equality passes
- CGPA lower fails
- backlog equality passes
- too many backlog fails
- deadline passed
- non-published drive

## State transitions

Test every valid and invalid drive/application edge.

## API

- student cannot create drive
- coordinator can
- student cannot status-update application
- Apply rejects ineligible
- Apply rejects expired
- Apply rejects foreign resume
- duplicate Apply conflicts
- document metadata rejects foreign prefix
- signed URL rejects unrelated document
- push subscription cannot spoof user id

## Edge

- draft insert ignored
- published insert processed
- draft→published processed
- cosmetic update ignored
- application no-op ignored
- status change processed
- duplicate webhook creates no duplicate notification
- expired endpoint removed

---

# 41. Deliverables

Only:

```text
app/api/**
lib/contracts/**
lib/domain/**
lib/server/**
supabase/functions/send-push/**
```

Handoff:

```text
API complete: yes/no
domain tests: yes/no
signed URL gate tested: yes/no
polling reads no-store: yes/no
Edge idempotency tested: yes/no
webhook assumptions documented: yes/no
```
