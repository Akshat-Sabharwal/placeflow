# OAuth and Session Integration — Code Generation Specification

> Load `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md` first.
>
> **Owned paths only:** `app/login/**`, `app/auth/callback/**`, `app/auth/auth-code-error/**`, `app/post-auth/**`, `lib/supabase/**`, `lib/auth/**`, root `proxy.ts`.
>
> Do not alter migrations, placement feature pages, business API handlers, Edge Functions or Service Worker code.

---

# 1. Mission

Build the single authentication/session foundation used by every other subsystem.

OAuth only:

```text
LinkedIn OIDC  ← preferred
Google
GitHub
```

Deliver:

- browser Supabase client
- request-scoped server Supabase client
- session-refresh Proxy
- OAuth login initiation
- PKCE callback/code exchange
- trusted role resolution
- post-auth role/onboarding routing
- reusable auth guards
- sign out

Do not build password, magic-link or phone login.

---

# 2. Core security distinction

## Authentication

Supabase Auth/OAuth proves:

```text
user identity
```

## Authorization

The sealed DB table:

```text
public.user_roles
```

decides:

```text
student | coordinator
```

Never authorize coordinator using:

```text
profiles.role
user_metadata
OAuth provider
request body
email domain alone
client-side route
```

There is no editable `profiles.role`.

---

# 3. Packages

Use current compatible stable versions of:

```text
@supabase/supabase-js
@supabase/ssr
```

The lockfile pins installed versions.

For Next.js cookie-based SSR, use `@supabase/ssr`.

Do not implement custom OAuth protocol handling beyond what Supabase/PKCE callback requires.

---

# 4. Environment variables this subsystem uses

Safe/public:

```text
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
NEXT_PUBLIC_APP_URL
```

Do not require LinkedIn/Google/GitHub client secrets in Next.js code.

Those provider credentials belong in Supabase Auth provider configuration.

Do not require `SUPABASE_SECRET_KEY` for normal OAuth session creation.

---

# 5. Browser Supabase client

Owned:

```text
lib/supabase/client.ts
```

Use current `createBrowserClient` pattern.

Concept:

```ts
createBrowserClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!
)
```

Only the publishable key enters browser code.

Consumers:

- login page
- UI direct Storage upload
- browser auth state where necessary

Other agents must import this factory rather than creating another Supabase browser client module.

---

# 6. Server Supabase client

Owned:

```text
lib/supabase/server.ts
```

Use `createServerClient` from `@supabase/ssr`.

Properties:

- request-specific cookie store
- publishable key
- user session/JWT
- RLS-aware
- fresh client per request
- never stored globally/module singleton

This client is used by:

- auth helpers
- server pages/layouts
- Route Handlers through Agent B

---

# 7. Why client-per-request matters

Serverless/warm compute may reuse module memory between requests.

A user-scoped client created at module scope can accidentally retain one request's session state.

Therefore:

```text
create client inside request/server function
```

not:

```text
const supabase = createServerClient(...) // shared forever
```

---

# 8. Session refresh Proxy

Owned:

```text
proxy.ts
lib/supabase/proxy.ts
```

Use current Next.js `proxy.ts` convention.

Purpose:

- read Supabase auth cookies
- refresh expired/near-expiry token state
- write updated cookies back to request/response
- ensure Server Components see refreshed auth
- ensure browser receives refreshed auth

Algorithm:

```text
request
  ↓
create request-specific Supabase SSR client
  ↓
wire cookie getAll/setAll correctly
  ↓
immediately verify claims
  ↓
return the SAME response carrying updated cookies/cache headers
```

Use current Supabase example's verified method, normally:

```text
supabase.auth.getClaims()
```

Do not run unrelated network/business code between client creation and claims refresh.

---

# 9. Proxy matcher

Cover routes that may need authenticated session state.

Exclude obvious static assets:

```text
_next/static
_next/image
favicon.ico
common image extensions
```

Proxy is **not** the final role authorization mechanism.

Backend API still calls requireStudent/requireCoordinator.

Feature layouts also call role guards.

---

# 10. Do not authorize with `getSession()` alone

A cookie/local-storage session object can be present without giving the server a newly verified user record.

Server security should use:

```text
getClaims()
```

for verified JWT identity in the normal path.

Use:

```text
getUser()
```

only where a fresh round-trip to the Auth service is actually needed.

Use `getSession()` when raw session/access token is the purpose, not as sole role authorization evidence.

---

# 11. Login page

Owned:

```text
app/login/page.tsx
```

Only three sign-in choices:

```text
Continue with LinkedIn
Continue with Google
Continue with GitHub
```

Order/visual priority:

1. LinkedIn largest/primary
2. Google secondary
3. GitHub secondary

No:

- email/password
- magic link
- phone
- “I am a student/coordinator” selector

All actors use the same login surface.

---

# 12. OAuth initiation

Browser Supabase client calls:

```text
signInWithOAuth
```

Exact providers:

```text
linkedin_oidc
google
github
```

Redirect target:

```text
{APP_ORIGIN}/auth/callback
```

If supporting a `next` path, allow only application-relative paths.

Never accept an arbitrary absolute redirect URL from query input.

---

# 13. OAuth callback chain

Understand two separate callbacks.

## External provider → Supabase

Hosted:

```text
https://<project-ref>.supabase.co/auth/v1/callback
```

Local Supabase CLI auth testing may use:

```text
http://localhost:54321/auth/v1/callback
```

This callback is configured in LinkedIn/Google/GitHub developer settings.

## Supabase → Next.js

Local:

```text
http://localhost:3000/auth/callback
```

Production:

```text
https://your-app.vercel.app/auth/callback
```

These belong in Supabase Auth's redirect allow-list.

Do not swap the two.

---

# 14. Callback Route Handler

Owned:

```text
app/auth/callback/route.ts
```

Algorithm:

1. parse request URL
2. read `code`
3. sanitize optional `next` to local relative path
4. if no code:
   ```text
   redirect /auth/auth-code-error
   ```
5. create server Supabase client
6. call:
   ```text
   exchangeCodeForSession(code)
   ```
7. if error:
   ```text
   redirect /auth/auth-code-error
   ```
8. success:
   ```text
   redirect /post-auth
   ```
   unless a deliberately validated local next path is used

Respect forwarded host/origin behavior on Vercel according to current Next.js/Supabase guidance.

Never render OAuth code/access/refresh token.

---

# 15. Auth error page

Owned:

```text
app/auth/auth-code-error/page.tsx
```

Show:

```text
We couldn't complete sign-in.
[Try again]
```

No token/error dump.

Server logs can contain non-secret diagnostic code/message.

---

# 16. Auth-user bootstrap expectation

The Database Agent owns an auth.users trigger that creates:

```text
profiles
user_roles(student)
```

This OAuth agent must **not** create a second onboarding/profile bootstrap record system.

After successful first OAuth login, assume those rows exist.

If a rare trigger failure means row missing:

- fail clearly
- do not silently create a competing role/profile record schema

---

# 17. LinkedIn OIDC boundary

LinkedIn is identity-first.

The app may receive/use identity/bootstrap fields such as:

```text
name
email
picture
provider identity
```

Do not make auth success dependent on:

```text
experience
education history
skills
certifications
projects
complete LinkedIn profile export
```

Those are not part of the ordinary self-service OIDC guarantee.

Placement-specific data belongs in `profiles`/documents.

---

# 18. Post-auth router

Owned:

```text
app/post-auth/page.tsx
```

Server-side decision.

Exact decision tree:

```text
verified session?
  no -> /login

trusted role = coordinator?
  yes -> /coordinator

role = student AND onboarding_completed_at IS NULL?
  yes -> /student/onboarding

otherwise
  -> /student
```

Load role from `user_roles`, not metadata.

---

# 19. Reusable auth helper surface

Own under:

```text
lib/auth/**
```

Recommended exported concepts:

```ts
type VerifiedViewer = {
  userId: string
  email?: string
  role: 'student' | 'coordinator'
}

getVerifiedViewer()
requireUser()
requireStudent()
requireCoordinator()
```

Behavior:

## `getVerifiedViewer`

- verify claims
- extract `sub`
- read own sealed role
- return normalized viewer or null/error

## `requireUser`

- redirect/throw if unauthenticated

## `requireStudent`

- require role student

## `requireCoordinator`

- require role coordinator

Feature layouts and API handlers consume these.

Do not let each downstream feature independently query/interpret role.

---

# 20. Page/layout guards vs API guards

Feature layout guard improves:

```text
navigation + UX + early denial
```

It does **not** replace API authorization.

Example:

```text
/coordinator layout calls requireCoordinator()
```

but:

```text
POST /api/drives still calls requireCoordinator()
```

because a malicious user can call APIs without rendering a page.

---

# 21. Coordinator bootstrap operational flow

There is no coordinator signup.

Flow:

1. future coordinator logs in once with OAuth
2. auth trigger creates:
   ```text
   profile
   role=student
   ```
3. trusted developer/admin updates:
   ```text
   user_roles.role = coordinator
   ```
4. user signs in/refreshes
5. role lookup now returns coordinator
6. `/post-auth` routes to coordinator UI

No role-management UI.

---

# 22. Why role is a DB lookup instead of JWT app_metadata here

Trusted `app_metadata` is a valid authorization location in Supabase, but this hackathon chooses a small sealed `user_roles` table because:

- promotion is transparent in SQL
- no token-refresh timing issue for role change
- RLS can inspect the same canonical role table
- role is not user-editable
- simpler multi-agent contract

Do not simultaneously implement both systems as competing sources of truth.

---

# 23. Sign out

Own one canonical implementation.

Recommended path:

```text
POST /auth/signout
```

Flow:

```text
server Supabase client
→ signOut()
→ refresh/revalidate as needed
→ redirect /login
```

UI calls this.

Do not create separate student/coordinator sign-out logic.

---

# 24. Authenticated response caching

User/session responses must not be shared across users.

Do not use ISR for:

```text
post-auth
authenticated layouts/pages that refresh session
auth callback
```

Preserve Supabase SSR cache-control headers when refreshing cookies.

---

# 25. Provider-specific failure UX

If `signInWithOAuth` fails before redirect:

- restore button enabled state
- show concise provider-specific error
- let user choose another provider

No automatic retry loop.

---

# 26. Multiple providers

Hackathon scope:

- three login choices
- no account-link/unlink settings UI
- no custom identity merge service
- no automatic merge based solely on similar names

Users should prefer LinkedIn, with Google/GitHub as fallbacks.

---

# 27. Tests

## Provider start

- LinkedIn uses `linkedin_oidc`
- Google uses `google`
- GitHub uses `github`
- redirect points to app callback
- external malicious next redirect is rejected

## Callback

- missing code -> auth error
- invalid code exchange -> auth error
- valid exchange -> post-auth
- no code/token leak

## Role routing

- no session -> login
- student incomplete -> onboarding
- student complete -> student home
- coordinator -> coordinator home
- user metadata cannot self-promote

## Session

- protected request remains authenticated through refresh
- refreshed cookies reach response/browser
- no module-global user-scoped Supabase client

## Signout

- session cleared
- protected page returns to login

---

# 28. Deliverables

Only:

```text
app/login/**
app/auth/callback/**
app/auth/auth-code-error/**
app/post-auth/**
lib/supabase/client.ts
lib/supabase/server.ts
lib/supabase/proxy.ts
lib/auth/**
proxy.ts
```

Handoff:

```text
LinkedIn OIDC wired: yes/no
Google wired: yes/no
GitHub wired: yes/no
PKCE exchange wired: yes/no
Proxy refresh verified: yes/no
trusted role lookup verified: yes/no
post-auth routing verified: yes/no
signout verified: yes/no
```
