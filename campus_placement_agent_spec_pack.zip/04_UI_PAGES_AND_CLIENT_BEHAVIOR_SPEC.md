# UI Pages and Client Behavior — Code Generation Specification

> Load `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md` first.
>
> **Owned paths only:** `app/student/**`, `app/coordinator/**`, `components/**`, `providers/**`, `lib/api-client/**`, `lib/queries/**`, `lib/ui/**`, `public/sw.js`.
>
> Do not create/rename API routes, migrations, OAuth callback/proxy files, backend domain rules or Supabase Edge Functions.

---

# 1. Mission

Build a minimal, coherent operational UI for exactly two roles:

```text
student
coordinator
```

The interface must make the shared placement workflow obvious in a live demo.

Design priorities:

```text
clarity
low cognitive load
fast navigation
clean loading/error states
visible near-live changes
mobile usability
```

Avoid enterprise-dashboard clutter.

---

# 2. Styling ownership

Primary:

```text
Chakra UI
```

Use Chakra for:

```text
Button
Input
Select
Form controls
Card
Table
Tabs
Dialog
Drawer
Badge
Alert
Toast
Menu
```

Tailwind only for:

```text
layout
grid
flex
gap
responsive arrangement
small width/spacing utilities
```

Do not deeply restyle the same component through both systems.

---

# 3. State architecture

## Server state

TanStack Query:

```text
profile
drives
applications
documents
notifications
applicant lists
```

## Local UI state

React state:

```text
dialog open
selected filter
form draft
selected resume
upload pending state
tab selection
```

No Redux/Zustand required.

No Supabase Realtime state.

---

# 4. Query provider

Own:

```text
providers/query-provider.tsx
```

One browser QueryClient.

Principles:

- reasonable retries for temporary network failure
- do not retry obvious permanent 4xx forever
- refetch-on-focus/reconnect remains useful
- no global background interval polling
- preserve old data during background refetch where sensible

Do not instantiate a new QueryClient per page render.

---

# 5. Canonical query keys

Own central key helpers:

```text
lib/queries/keys.ts
```

Logical keys exactly:

```ts
viewer: ['viewer']
profile: ['profile']
drives(filters): ['drives', filters]
drive(id): ['drive', id]
myApplications(filters): ['applications', 'me', filters]
driveApplications(id, filters): ['drive-applications', id, filters]
documents: ['documents']
notifications(filters): ['notifications', filters]
```

No ad-hoc duplicate key spelling.

---

# 6. Polling intervals

```text
Student drive feed              15s
Active drive detail             15s if useful
Student applications            10s
Coordinator applicant list       5s
Profile                           no interval
Documents                         no interval
Coordinator editor                no interval
Notifications                     optional 15–30s
```

Do **not** set:

```text
refetchIntervalInBackground: true
```

Important off-screen events use Web Push.

A local successful mutation should invalidate relevant queries immediately.

---

# 7. API client

Own:

```text
lib/api-client/**
```

Suggested files:

```text
client.ts
errors.ts
profile.ts
drives.ts
applications.ts
documents.ts
notifications.ts
push.ts
```

One central `ApiError`.

Fetchers must:

1. call canonical API
2. parse `{data}` or `{error}`
3. throw typed error on non-2xx
4. never convert a server error into `[]`

Import DTOs/Zod from:

```text
lib/contracts/**
```

Do not recreate competing Drive/Application/Profile types.

---

# 8. Student route tree

```text
app/student/
├── layout.tsx
├── page.tsx
├── onboarding/
│   └── page.tsx
├── drives/
│   ├── page.tsx
│   └── [id]/
│       └── page.tsx
├── applications/
│   └── page.tsx
├── documents/
│   └── page.tsx
└── profile/
    └── page.tsx
```

Student layout imports Agent C's `requireStudent` or equivalent.

Do not implement role resolution again.

---

# 9. Student navigation

Exactly:

```text
Home
Drives
Applications
Documents
Profile
```

Also:

```text
notification bell
profile/signout menu
```

Mobile may use drawer or compact bottom nav but information architecture stays identical.

---

# 10. `/student/onboarding`

Purpose:

Collect application-owned placement data after first OAuth login.

Fields:

```text
Full name
Roll number
Branch
Graduation year
CGPA
Backlogs
LinkedIn URL optional
GitHub URL optional
```

Do not ask:

```text
password
email again
complete LinkedIn work history
unnecessary personal demographics
```

Submit:

```text
PATCH /api/profile
```

UX:

- shared Zod/client validation for fast feedback
- server remains final authority
- disable submit while pending
- invalidate profile on success
- navigate `/student`
- map validation errors to form/general alert

---

# 11. `/student` dashboard

Minimal.

Show:

```text
Hi, {firstName}

Open eligible drives
Active applications
Latest application status

Latest 2–4 relevant drive cards
Recent notification/application activity
```

No charts.

No placement analytics.

No gamification.

Drive card:

```text
company
role
package text
deadline
eligibility badge
application state if applied
View drive
```

---

# 12. `/student/drives`

Query:

```text
GET /api/drives
```

Poll:

```text
15s
```

Filters only:

```text
Open
Applied
All
```

Optional small text search:

```text
company / role
```

Card:

```text
Company
Role
Package
Deadline
Drive date/location
Eligibility
Applied state
```

When polling reveals a new drive:

- insert naturally into list
- optional subtle `New` badge
- no disruptive animation

---

# 13. `/student/drives/[id]`

Query:

```text
GET /api/drives/{id}
```

Render:

```text
company
job role
package
location
drive date
registration deadline
description

eligibility requirements:
  branches
  years
  minimum CGPA
  maximum backlogs

your eligibility:
  eligible ✓
  OR exact reason list

selected resume
application state
Apply
```

Button states:

```text
ineligible -> disabled + reason
already applied -> disabled / Applied
closed/deadline -> disabled
eligible -> enabled
```

This is UX only. Server Apply still recomputes.

---

# 14. Apply mutation

Flow:

```text
select existing resume
→ optional confirm dialog
→ POST /api/drives/{id}/apply
```

While pending:

- disable Apply button
- do not allow duplicate clicks

Success:

```text
toast
invalidate ['applications','me',...]
invalidate ['drive',driveId]
```

Error handling:

```text
DUPLICATE_APPLICATION -> already applied
INELIGIBLE             -> refetch/show reasons
DEADLINE_PASSED        -> refetch drive
DRIVE_CLOSED           -> refetch drive
```

Do not optimistically invent an application before server acceptance.

---

# 15. `/student/applications`

Query:

```text
GET /api/applications/me
```

Poll:

```text
10s while active
```

Show per application:

```text
Company
Role
Status
Applied date
Drive date
```

Statuses use both text and badge/visual cue:

```text
Applied
Shortlisted
Selected
Rejected
```

No overengineered timeline necessary.

During background refetch, keep old content on screen rather than flashing skeleton every 10s.

---

# 16. `/student/documents`

Query:

```text
GET /api/documents
```

No interval polling.

UI:

```text
Upload resume/document
Filename
Type
Uploaded date
Size
Delete
```

Canonical input:

```text
PDF
<= 10 MiB
```

Client checks improve UX but are not security controls.

---

# 17. Direct Storage upload — exact client flow

This is the intentionally direct browser→Supabase path.

1. user chooses file
2. verify for UX:
   ```text
   PDF
   <=10MiB
   ```
3. obtain authenticated user id from viewer/auth context
4. generate UUID using browser crypto
5. canonical path:
   ```text
   {userId}/{documentType}/{uuid}.pdf
   ```
6. use Agent C's Supabase browser client:
   ```text
   storage.from('student-documents').upload(path,file)
   ```
7. after successful object upload:
   ```text
   POST /api/documents/metadata
   ```
8. metadata success:
   - invalidate `documents`
   - toast
9. metadata failure:
   - show explicit recoverable error
   - do not directly delete/overwrite the Storage object from the browser
   - the metadata API performs best-effort privileged cleanup when appropriate
   - refetch documents and never pretend the document was registered

No Vercel binary proxy.

---

# 18. Document deletion

UI calls:

```text
DELETE /api/documents/{id}
```

Do not call Storage UPDATE/DELETE directly from normal UI. Browser Storage access is intentionally immutable after upload.

Backend may return:

```text
409 DOCUMENT_IN_USE
```

Message:

```text
This resume is attached to an existing application and cannot be deleted.
```

---

# 19. `/student/profile`

Query:

```text
GET /api/profile
```

No polling.

Edit the same application-owned fields as onboarding.

OAuth identity/email can be read-only.

Never render a user-editable role selector.

---

# 20. Notification bell/drawer

Authenticated student shell.

Query:

```text
GET /api/notifications
```

Display:

```text
title
body
time
unread marker
```

Click:

```text
navigate to URL
mark read
```

Persistent notification history must work even if browser push is disabled.

---

# 21. Push opt-in UX

Do not request Notification permission on page load.

Show explicit CTA:

```text
Never miss a placement update
[Enable notifications]
```

Only after click:

1. wait for/register Service Worker
2. request Notification permission
3. if granted:
   - subscribe with `NEXT_PUBLIC_VAPID_PUBLIC_KEY`
   - POST canonical PushSubscription to API
4. if denied:
   - explain in-app updates still work
   - do not repeatedly nag

---

# 22. `public/sw.js`

Own Service Worker implementation.

Handle:

```text
push
notificationclick
```

Push:

```text
parse canonical PushPayload
showNotification(title,{body,data:{url,...}})
```

Click:

```text
close
focus matching open client if practical
else open payload.url
```

Do not expose private data in notification.

Do not use Service Worker as a database/cache authority.

---

# 23. Coordinator route tree

```text
app/coordinator/
├── layout.tsx
├── page.tsx
└── drives/
    ├── page.tsx
    ├── new/
    │   └── page.tsx
    └── [id]/
        └── page.tsx
```

Coordinator layout imports Agent C's coordinator guard.

---

# 24. `/coordinator`

Minimal:

```text
Active drives
Current application count
Latest drives
Create Drive button
```

No analytics chart.

---

# 25. `/coordinator/drives`

Query:

```text
GET /api/drives
```

Rows/cards:

```text
company
role
status
deadline
application count
Manage
```

Simple filters:

```text
Active
Completed
Cancelled
All
```

No rapid polling required on the list.

---

# 26. `/coordinator/drives/new`

Fields:

```text
Company
Job role
Description
Location
Package text

Eligible branches
Eligible graduation years
Minimum CGPA
Maximum backlogs

Registration deadline
Drive date
```

Actions:

```text
Save draft
Publish
```

Mutation:

```text
POST /api/drives
```

Do not create a generic visual eligibility rule builder.

---

# 27. `/coordinator/drives/[id]`

Three tabs:

```text
Overview
Applicants
Edit
```

## Overview

- drive fields
- status
- application counts

## Applicants

Query:

```text
GET /api/drives/{id}/applications
```

Poll:

```text
5s while tab active
```

Columns:

```text
Name
Roll number
Branch
CGPA
Backlogs
Resume
Status
```

## Edit

Reuse the same drive form model.

Mutation:

```text
PATCH /api/drives/{id}
```

---

# 28. Applicant status update

Action:

```text
PATCH /api/applications/{applicationId}/status
```

Offer only sensible target transitions where shared contract provides that information.

Success:

```text
toast
invalidate ['drive-applications',driveId,...]
```

Prefer simple server-confirmed mutation over elaborate optimistic terminal-state changes.

---

# 29. Resume access UX

Applicant row:

```text
View resume
```

On click only:

```text
GET /api/documents/{resumeDocumentId}/url
```

Then open/preview temporary URL.

Do not:

- prefetch all signed URLs
- store signed URL in localStorage
- keep it in long-lived query cache
- display permanent Storage link

---

# 30. Loading semantics

## Initial loading

Skeleton/spinner.

## Poll background refresh

Keep existing data.

Optionally small refresh indicator.

Do not blank/refill every interval.

## Mutation

Disable relevant action only.

Do not lock unrelated screen controls.

---

# 31. Empty states

Use domain-specific copy.

Examples:

```text
No placement drives are open right now.
You haven't applied to any drives yet.
Upload a resume before applying to a drive.
No students have applied to this drive yet.
```

Avoid generic `No data`.

---

# 32. Error semantics

Initial failure:

- Alert
- retry button when useful

Polling refresh failure:

- keep stale cached data
- small “Could not refresh” indicator
- allow normal retry policy

401:

- auth layer/login

403:

- unauthorized/role home

Never translate API error into empty list.

---

# 33. Accessibility

Required:

- visible labels for all controls
- status not color-only
- keyboard-operable dialogs/menus
- clear focus behavior
- accessible loading text
- table action labels
- notification critical meaning also persists in app content
- form error association where practical

---

# 34. Responsive design

Desktop is hackathon presentation target.

Student mobile still must work.

Desktop:

```text
navigation + cards/tables
```

Mobile:

```text
stacked drive cards
drawer/compact nav
applicant cards or safe table overflow
```

No whole-page horizontal overflow.

---

# 35. Visual tone

Aim:

```text
clean
institutional
modern
minimal
operational
```

Avoid:

```text
large marketing heroes after login
gamification
excessive gradients
glassmorphism everywhere
BI-dashboard charts
social-app visual language
```

---

# 36. Component suggestions

Reusable, not mandatory exact names:

```text
DriveCard
DriveStatusBadge
ApplicationStatusBadge
EligibilityPanel
DriveForm
ApplicantTable
DocumentUploader
DocumentList
NotificationBell
EmptyState
ApiErrorAlert
PageSkeleton
```

Do not create 50 tiny abstraction components for trivial one-off markup.

---

# 37. Required UI tests

- Drive card renders eligibility correctly from API data
- Apply disabled for API-described ineligible state
- Apply double-click prevented while pending
- successful Apply invalidates drive + applications
- documents query has no interval
- PDF >10MiB rejected client-side
- non-PDF rejected client-side
- metadata API only called after Storage upload success
- DOCUMENT_IN_USE shown correctly
- applicant query polls ~5s only while active
- applications query polls ~10s
- drives polls ~15s
- no background interval polling enabled
- status mutation invalidates applicant key
- push permission only after click
- Service Worker parses canonical payload
- resume signed URL fetched only on demand

---

# 38. Deliverables

Only:

```text
app/student/**
app/coordinator/**
components/**
providers/**
lib/api-client/**
lib/queries/**
lib/ui/**
public/sw.js
```

Handoff:

```text
student pages: yes/no
coordinator pages: yes/no
canonical query keys: yes/no
polling intervals correct: yes/no
background polling off: yes/no
direct Storage upload: yes/no
push opt-in + SW: yes/no
signed resume on-demand: yes/no
mobile pass: yes/no
```
