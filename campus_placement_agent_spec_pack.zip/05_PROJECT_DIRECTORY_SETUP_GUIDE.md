# Project Directory Setup Guide — Very Naive Step-by-Step

This guide starts from an empty folder and gets the developer to a correctly structured project ready for the specialist agents.

You do not need to understand every folder before creating it. The goal is to reserve a single agreed structure so agents do not invent competing layouts.

---

# 1. Final deployment model

One Git repository:

```text
Next.js application
Supabase configuration/migrations
Supabase Edge Function
```

Deployment:

```text
GitHub repository
   ├── Vercel
   │     └── Next.js pages + Route Handlers
   │
   └── Supabase
         ├── Auth
         ├── PostgreSQL
         ├── Storage
         ├── Database Webhooks
         └── send-push Edge Function
```

There is no second backend repository.

---

# 2. Install basic tools

Required:

```text
Git
Node.js 22+
npm
code editor
Docker-compatible runtime if running Supabase locally
```

Check:

```bash
git --version
node --version
npm --version
```

Use Node 22+ as this project's baseline.

Do not continue on a stale machine just because an older Next.js example still starts.

---

# 3. Make project folder

```bash
mkdir campus-placement-platform
cd campus-placement-platform
```

This becomes repository root.

---

# 4. Create Next.js in the current directory

First inspect current CLI:

```bash
npx create-next-app@latest --help
```

Required choices:

```text
TypeScript: yes
ESLint: yes
Tailwind: yes
App Router: yes
src directory: no
import alias: @/*
```

A typical equivalent command is:

```bash
npx create-next-app@latest . --typescript --eslint --tailwind --app --import-alias "@/*"
```

If the current CLI wording differs, choose the equivalent interactive options.

All specs assume no `src/` prefix.

---

# 5. Git

If needed:

```bash
git init
```

Then:

```bash
git status
```

Make a clean scaffold commit before large agent work if possible.

---

# 6. Install project libraries

Required categories/packages:

```bash
npm install @supabase/supabase-js @supabase/ssr
npm install @tanstack/react-query
npm install @chakra-ui/react
npm install zod
```

If current Chakra requires documented peer packages for its major version, install those from current Chakra documentation.

Do not copy a Chakra v1/v2 installation command from an old article blindly.

The final:

```text
package-lock.json
```

must be committed.

---

# 7. Supabase CLI

Prefer a project-controlled/current Supabase CLI workflow.

Check:

```bash
npx supabase --help
npx supabase --version
```

For any command whose flags you do not know:

```bash
npx supabase <command> --help
```

Do not make up flags.

---

# 8. Initialize Supabase folder

Inspect:

```bash
npx supabase init --help
```

Then:

```bash
npx supabase init
```

Expected:

```text
supabase/
  config.toml
  ...
```

Migrations will later be created by the Database Agent.

---

# 9. Reserve folder skeleton

From repository root:

```bash
mkdir -p \
  app/login \
  app/auth/callback \
  app/auth/auth-code-error \
  app/post-auth \
  app/student/onboarding \
  app/student/drives \
  app/student/applications \
  app/student/documents \
  app/student/profile \
  app/coordinator/drives/new \
  app/api \
  components \
  providers \
  lib/api-client \
  lib/queries \
  lib/ui \
  lib/contracts \
  lib/domain \
  lib/server \
  lib/auth \
  lib/supabase \
  lib/types \
  supabase/functions/send-push
```

Do not fill each folder with independently invented helper code.

They are ownership reservations.

---

# 10. Final directory target

```text
campus-placement-platform/
│
├── app/
│   ├── login/
│   │   └── page.tsx
│   │
│   ├── auth/
│   │   ├── callback/
│   │   │   └── route.ts
│   │   └── auth-code-error/
│   │       └── page.tsx
│   │
│   ├── post-auth/
│   │   └── page.tsx
│   │
│   ├── student/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── onboarding/page.tsx
│   │   ├── drives/
│   │   │   ├── page.tsx
│   │   │   └── [id]/page.tsx
│   │   ├── applications/page.tsx
│   │   ├── documents/page.tsx
│   │   └── profile/page.tsx
│   │
│   ├── coordinator/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── drives/
│   │       ├── page.tsx
│   │       ├── new/page.tsx
│   │       └── [id]/page.tsx
│   │
│   └── api/
│       ├── profile/
│       ├── drives/
│       ├── applications/
│       ├── documents/
│       ├── notifications/
│       └── push/
│
├── components/
├── providers/
│
├── lib/
│   ├── api-client/
│   ├── queries/
│   ├── ui/
│   ├── contracts/
│   ├── domain/
│   ├── server/
│   ├── auth/
│   ├── supabase/
│   └── types/
│       └── database.types.ts
│
├── public/
│   └── sw.js
│
├── supabase/
│   ├── config.toml
│   ├── migrations/
│   ├── seed.sql
│   └── functions/
│       └── send-push/
│
├── proxy.ts
├── .env.local
├── .env.example
├── package.json
└── package-lock.json
```

---

# 11. `.env.example`

Create:

```bash
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=
SUPABASE_SECRET_KEY=

NEXT_PUBLIC_APP_URL=http://localhost:3000

NEXT_PUBLIC_VAPID_PUBLIC_KEY=
```

No real secret values.

Commit this file.

---

# 12. `.env.local`

Create:

```text
.env.local
```

with real local values later.

Make sure `.gitignore` prevents it from being committed.

Safe pattern:

```text
.env*
!.env.example
```

Check before commit:

```bash
git status
```

---

# 13. Create Supabase hosted project

In Supabase Dashboard:

1. create project
2. choose region
3. set database password
4. wait for provisioning
5. open Connect/API settings
6. note:
   - project URL
   - project reference
   - publishable key
   - secret key

Do not expose database password or secret key in browser code.

---

# 14. Link local Supabase to hosted project

Inspect:

```bash
npx supabase link --help
```

Then link to the correct project reference.

The exact command should come from current CLI help.

Understand:

```text
local Supabase != hosted Supabase
```

Linking simply lets the CLI know which hosted project you intend to operate.

---

# 15. Agent execution order

## First — Database Agent

Give:

```text
00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md
01_DATABASE_MIGRATIONS_AND_SCHEMA_SPEC.md
```

It owns:

```text
supabase/migrations
supabase/seed.sql
lib/types/database.types.ts
```

## Second — OAuth Agent

Give:

```text
00...
03_OAUTH...
```

It owns auth/session/Proxy files.

## Third — Backend Agent

Give:

```text
00...
02_SERVER...
```

It owns REST/contracts/domain/Edge.

## Fourth — UI Agent

Give:

```text
00...
04_UI...
```

It owns student/coordinator pages/query hooks/client/service worker.

Do not let two agents edit the same owned path at once.

---

# 16. Local database workflow

Before using local DB commands:

```bash
npx supabase start --help
npx supabase db --help
```

Use installed CLI's exact commands to:

```text
start local Supabase
apply/reset migrations
verify schema
```

Fix schema in migration files, not only by manually editing Dashboard state.

---

# 17. Generate DB TypeScript types

After migration success:

```bash
npx supabase gen types --help
```

Generate to:

```text
lib/types/database.types.ts
```

This is generated code.

Never hand-edit it.

---

# 18. Start Next.js

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

Initial first meaningful page:

```text
/login
```

---

# 19. Configure OAuth only after Supabase project exists

Use:

```text
06_API_KEYS_AND_EXTERNAL_INTEGRATIONS_GUIDE.md
```

Order:

```text
LinkedIn OIDC
Google
GitHub
```

Test one provider at a time.

---

# 20. First-user flow

Once OAuth works:

1. log in as test student
2. auth trigger creates:
   ```text
   profiles row
   user_roles(student)
   ```
3. post-auth routes student to onboarding
4. fill onboarding
5. verify `/student`

Do not manually create a profile through a second code path.

---

# 21. Create coordinator account

1. coordinator logs in once normally
2. starts as student
3. developer opens Supabase SQL Editor
4. promotes the exact `user_roles` row to coordinator
5. coordinator signs in/refreshes
6. post-auth now routes `/coordinator`

There is no “become coordinator” button.

---

# 22. Storage integration test before UI debugging

Database Agent creates private:

```text
student-documents
```

Before blaming UI, verify:

Student A:

```text
can upload:
A_UUID/resume/file.pdf
```

Student A:

```text
cannot upload:
B_UUID/resume/file.pdf
```

Bucket must not be public.

---

# 23. Full integration testing order

Do not debug the whole application at once.

## Stage 1 — Auth

```text
login
callback
session refresh
student/coordinator routing
```

## Stage 2 — Profile

```text
onboarding
reload
edit
```

## Stage 3 — Documents

```text
direct Storage upload
metadata API
list
delete unused document
```

## Stage 4 — Drives

```text
coordinator draft
publish
student sees through GET/poll
```

## Stage 5 — Apply

```text
eligible succeeds
ineligible fails
duplicate fails
foreign resume fails
```

## Stage 6 — Coordinator workflow

```text
applicant list
temporary resume URL
status update
```

## Stage 7 — Polling

Use two browser windows.

Student Apply:

```text
coordinator sees within about 5s
```

Coordinator shortlist:

```text
student sees within about 10s
```

## Stage 8 — Push

```text
enable notifications
publish drive
verify push
```

---

# 24. Configure Edge Function before webhook

Deploy/test:

```text
send-push
```

Store its secrets.

Only then configure DB webhooks.

Otherwise every DB event points at a broken destination while you are still setting up.

---

# 25. Build check

Before Vercel:

```bash
npm run lint
npm run build
```

Run tests supplied by agents.

Do not use Vercel as the first place you discover TypeScript compile failures.

---

# 26. Vercel deployment

Typical workflow:

```text
push Git repository to GitHub
→ Vercel New Project
→ import repository
→ set environment variables
→ deploy
```

Result:

```text
https://your-app.vercel.app
```

Set production:

```text
NEXT_PUBLIC_APP_URL=https://your-app.vercel.app
```

---

# 27. Production OAuth URLs

External provider callback stays:

```text
https://<project-ref>.supabase.co/auth/v1/callback
```

Supabase Auth redirect allow-list must include:

```text
https://your-app.vercel.app/auth/callback
```

These are different URLs for different hops.

---

# 28. Webhook configuration

After Edge deploy:

Watch:

```text
drives INSERT
drives UPDATE
applications UPDATE
```

Destination:

```text
https://<project-ref>.supabase.co/functions/v1/send-push
```

Add the shared webhook-secret header.

Edge code filters meaningful old→new transitions.

---

# 29. Git discipline with agents

Preferred branches:

```text
agent/db
agent/auth
agent/backend
agent/ui
```

Before starting:

```bash
git status
```

After agent output:

```bash
git diff
npm run build
```

If two agents modify the same owned file, stop.

Check the ownership map rather than blindly resolving merge text.

---

# 30. Final production smoke test

Use two real test accounts:

```text
student
coordinator
```

Run:

1. OAuth login
2. coordinator publish
3. student drive polling sees drive
4. student apply
5. coordinator polling sees applicant
6. coordinator opens signed resume
7. coordinator shortlists
8. student polling sees status
9. push/in-app notification works

If this path works, the hackathon's main story works.
