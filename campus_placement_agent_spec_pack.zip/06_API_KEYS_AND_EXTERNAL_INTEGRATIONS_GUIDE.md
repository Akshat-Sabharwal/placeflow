# API Keys and External Integrations — Very Naive Layman Guide

This guide explains every external value the project needs, where to get it, and exactly where it belongs.

The single most important rule:

> **Anything named public/publishable may be visible to the browser. Anything named secret/private must never be placed in `NEXT_PUBLIC_*`, committed to Git or pasted into client code.**

---

# 1. Services you need

```text
Supabase
Vercel
LinkedIn Developer
Google Cloud / Google OAuth
GitHub Developer Settings
Web Push VAPID key pair
```

You do not need Firebase/Auth0/Redis/WebSocket hosting.

---

# 2. Three places configuration lives

## A. Next.js/Vercel variables

Consumed by Next.js app.

Examples:

```text
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
SUPABASE_SECRET_KEY
NEXT_PUBLIC_APP_URL
NEXT_PUBLIC_VAPID_PUBLIC_KEY
```

## B. Supabase Auth provider settings

Stores external OAuth credentials:

```text
LinkedIn client id + secret
Google client id + secret
GitHub client id + secret
```

These provider secrets do not need to be in browser env variables.

## C. Supabase Edge Function secrets

Stores:

```text
VAPID_PRIVATE_KEY
VAPID_PUBLIC_KEY if worker library needs it
PLACEMENT_WEBHOOK_SECRET
```

---

# 3. Supabase Project URL

In Supabase project, use current Connect/API area.

It resembles:

```text
https://abcdefgh.supabase.co
```

Local `.env.local`:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://abcdefgh.supabase.co
```

Vercel:

```text
NEXT_PUBLIC_SUPABASE_URL
```

This is public.

---

# 4. Supabase publishable key

Current key style resembles:

```text
sb_publishable_...
```

Get it from current Supabase Connect/API Keys area.

Local:

```bash
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
```

Vercel:

```text
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
```

It is browser-safe **because actual access is restricted with table privileges/RLS**.

A publishable key is not a magic private password.

---

# 5. Supabase secret key

Current secret key may resemble:

```text
sb_secret_...
```

This is privileged.

Local trusted server code:

```bash
SUPABASE_SECRET_KEY=sb_secret_...
```

Vercel:

```text
SUPABASE_SECRET_KEY
```

Never:

```text
NEXT_PUBLIC_SUPABASE_SECRET_KEY
```

Never paste into:

```text
React component
public/sw.js
README
screenshot
GitHub issue
browser console snippet
```

If leaked, rotate it.

---

# 6. Old `anon` and `service_role` tutorials

Older examples may use:

```text
anon
service_role
```

This spec uses modern terminology:

```text
publishable
secret
```

Do not mix old/new variables just because a 2023 blog does.

Use current Supabase key guidance for your actual project.

---

# 7. App URL

Local:

```bash
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

Production:

```bash
NEXT_PUBLIC_APP_URL=https://your-app.vercel.app
```

Public.

---

# 8. OAuth callback chain — understand this first

There are **two hops**.

```text
LinkedIn/Google/GitHub
        ↓
Supabase Auth callback
        ↓
your Next.js /auth/callback
```

## External provider callback

Enter this in LinkedIn/Google/GitHub:

```text
https://<project-ref>.supabase.co/auth/v1/callback
```

For local Supabase CLI OAuth testing, provider callback may be:

```text
http://localhost:54321/auth/v1/callback
```

## App callback

Put these in Supabase Auth redirect allow-list:

```text
http://localhost:3000/auth/callback
https://your-app.vercel.app/auth/callback
```

Do not swap provider callback and app callback.

---

# 9. LinkedIn OIDC — preferred login

## 9.1 Create LinkedIn app

Go to LinkedIn Developer portal.

Create app.

LinkedIn may ask for:

```text
app name
LinkedIn Page/company association
logo
```

## 9.2 Enable correct product

Products:

```text
Sign In with LinkedIn using OpenID Connect
```

Request/enable this.

Do not use deprecated old LinkedIn provider.

## 9.3 Get Supabase callback

Supabase:

```text
Authentication
→ Sign In / Providers
→ LinkedIn (OIDC)
```

Copy callback:

```text
https://<project-ref>.supabase.co/auth/v1/callback
```

## 9.4 Put callback into LinkedIn

Add exact URL as authorized redirect URL.

## 9.5 Copy LinkedIn credentials

LinkedIn gives:

```text
Client ID
Client Secret
```

## 9.6 Paste only into Supabase

Supabase Provider settings:

```text
LinkedIn (OIDC) Enabled = ON
Client ID = ...
Client Secret = ...
```

Save.

## 9.7 Next.js code

Only needs:

```text
provider: 'linkedin_oidc'
```

The browser does not need LinkedIn client secret.

---

# 10. LinkedIn full-profile expectation

Normal OIDC login is not a promise of a user's entire LinkedIn professional database.

Do not require:

```text
full experience history
education list
skills list
certifications
projects
```

The app collects authoritative placement data itself:

```text
roll number
branch
graduation year
CGPA
backlogs
resume
```

LinkedIn remains preferred identity/professional-profile linking.

---

# 11. Google OAuth

High-level:

1. Google Cloud Console
2. create/select project
3. configure OAuth consent
4. create Web OAuth client
5. redirect URI:
   ```text
   https://<project-ref>.supabase.co/auth/v1/callback
   ```
6. Google gives:
   ```text
   Client ID
   Client Secret
   ```
7. Supabase:
   ```text
   Authentication → Providers → Google
   ```
8. enable
9. paste ID + secret
10. save

Next.js:

```text
provider: 'google'
```

No Google secret in browser.

---

# 12. GitHub OAuth

GitHub:

```text
Settings
→ Developer settings
→ OAuth Apps
→ New OAuth App
```

Homepage:

```text
http://localhost:3000
```

or production app URL.

Authorization callback:

```text
https://<project-ref>.supabase.co/auth/v1/callback
```

Copy:

```text
Client ID
Client Secret
```

Supabase:

```text
Authentication
→ Providers
→ GitHub
```

Enable and paste.

Next.js:

```text
provider: 'github'
```

---

# 13. Supabase redirect allow-list

Supabase must be permitted to send the OAuth session back to your application.

Add:

```text
http://localhost:3000/auth/callback
https://your-app.vercel.app/auth/callback
```

If later using custom domain:

```text
https://placements.example.edu/auth/callback
```

add it.

Avoid permissive wildcards unless you understand them.

---

# 14. Supabase Site URL

Set default site URL appropriately.

Development:

```text
http://localhost:3000
```

Production:

```text
https://your-app.vercel.app
```

When deploying, verify it. Do not assume Supabase changes it automatically.

---

# 15. VAPID keys in plain English

Web Push uses a pair:

```text
public VAPID key
private VAPID key
```

Public:

```text
browser can know it
used to create push subscription
```

Private:

```text
only push-sending server/Edge worker knows it
proves sender identity
```

Generate once per environment and keep the pair together.

---

# 16. Generate VAPID keys

Use the pinned Web Push package/tool chosen by Backend Agent.

Read its installed CLI/help rather than copying a random `latest` command.

It should output:

```text
public key
private key
```

Save them securely.

Do not commit private key.

---

# 17. VAPID public key placement

Local:

```bash
NEXT_PUBLIC_VAPID_PUBLIC_KEY=...
```

Vercel:

```text
NEXT_PUBLIC_VAPID_PUBLIC_KEY
```

Supabase Edge Function may also need the public key depending on Web Push library.

Safe for browser.

---

# 18. VAPID private key placement

Put in:

```text
Supabase Edge Function secrets
```

Name:

```text
VAPID_PRIVATE_KEY
```

Never:

```text
NEXT_PUBLIC_VAPID_PRIVATE_KEY
```

Do not put it in `public/sw.js`.

---

# 19. Webhook shared secret

Database Webhook calls an internet-accessible Edge Function URL.

Protect the call with a random shared secret.

Name:

```text
PLACEMENT_WEBHOOK_SECRET
```

Store same value in:

1. Supabase Edge Function secret
2. DB Webhook custom header

Header:

```text
x-placement-webhook-secret: <value>
```

Do not store in browser.

---

# 20. Edge Function secrets

Before using CLI:

```bash
npx supabase secrets --help
```

Set conceptually:

```text
VAPID_PRIVATE_KEY
VAPID_PUBLIC_KEY
PLACEMENT_WEBHOOK_SECRET
```

The Edge Function may also receive current Supabase project credentials automatically according to platform runtime; follow current Supabase function docs rather than hardcoding them.

No secret goes in source.

---

# 21. Database Webhook configuration

Configure only after Edge Function is deployed.

Watch:

```text
public.drives INSERT
public.drives UPDATE
public.applications UPDATE
```

Destination:

```text
https://<project-ref>.supabase.co/functions/v1/send-push
```

Header:

```text
x-placement-webhook-secret
```

Why broad events?

The Edge Function examines:

```text
record
old_record
```

and ignores irrelevant changes.

Do not make dozens of per-field webhooks.

---

# 22. Vercel variable table

| Variable | Vercel | Browser-visible |
|---|---:|---:|
| `NEXT_PUBLIC_SUPABASE_URL` | yes | yes |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | yes | yes |
| `SUPABASE_SECRET_KEY` | yes, server only | no |
| `NEXT_PUBLIC_APP_URL` | yes | yes |
| `NEXT_PUBLIC_VAPID_PUBLIC_KEY` | yes | yes |
| `VAPID_PRIVATE_KEY` | normally Edge only | no |
| `PLACEMENT_WEBHOOK_SECRET` | Edge/Webhook only | no |

Principle:

```text
put a secret in the fewest systems that actually need it
```

---

# 23. OAuth credential placement table

| Credential | Supabase Auth | Next.js browser |
|---|---:|---:|
| LinkedIn Client ID | yes | not needed |
| LinkedIn Client Secret | yes | never |
| Google Client ID | yes | not needed |
| Google Client Secret | yes | never |
| GitHub Client ID | yes | not needed |
| GitHub Client Secret | yes | never |

Next.js tells Supabase which provider to use; Supabase holds provider secret.

---

# 24. `.env.local` example

```bash
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_REPLACE_ME

SUPABASE_SECRET_KEY=sb_secret_REPLACE_ME

NEXT_PUBLIC_APP_URL=http://localhost:3000

NEXT_PUBLIC_VAPID_PUBLIC_KEY=REPLACE_ME
```

If VAPID private/webhook secret are only used by Edge Function, they do not need to exist in `.env.local` for Next.js.

---

# 25. Why `NEXT_PUBLIC_` matters

Next.js exposes:

```text
NEXT_PUBLIC_*
```

to browser JavaScript.

Therefore these are obvious red flags:

```text
NEXT_PUBLIC_SUPABASE_SECRET_KEY
NEXT_PUBLIC_VAPID_PRIVATE_KEY
NEXT_PUBLIC_LINKEDIN_CLIENT_SECRET
NEXT_PUBLIC_GOOGLE_CLIENT_SECRET
NEXT_PUBLIC_GITHUB_CLIENT_SECRET
```

If you see one, stop.

---

# 26. Never commit secrets

Before commit:

```bash
git status
git diff --staged
```

Never commit:

```text
.env.local
provider secret screenshot
OAuth token
private VAPID key
Supabase secret key
debug dump with credentials
```

If a secret enters Git history, deleting the latest file is not enough.

Rotate the secret.

---

# 27. If something leaks

## Supabase secret

Rotate/revoke in Supabase, then update trusted server environments.

## OAuth client secret

Rotate in that provider, then update Supabase Auth provider settings.

## VAPID private key

Generate a new pair.

Existing subscriptions may need re-subscription because the application server key changed.

## Webhook secret

Generate a new value, update:

```text
Edge secret
Webhook header
```

---

# 28. OAuth troubleshooting

If one provider fails:

1. provider enabled in Supabase?
2. correct Client ID?
3. correct Client Secret?
4. provider redirect exactly:
   ```text
   https://<project-ref>.supabase.co/auth/v1/callback
   ```
5. Next.js callback allowed in Supabase redirect URLs?
6. production using HTTPS?
7. LinkedIn code uses `linkedin_oidc`?
8. LinkedIn OIDC product enabled?
9. accidentally using localhost setting in production?
10. inspect Supabase Auth logs before editing random code

---

# 29. Push troubleshooting

If browser subscription fails:

1. Service Worker registered?
2. notification permission granted after user click?
3. site secure/HTTPS? (`localhost` is development exception)
4. VAPID public key correct?
5. browser created PushSubscription?
6. subscription POST returned 2xx?
7. row exists in `push_subscriptions`?

If subscription exists but no push:

1. did DB webhook fire?
2. did Edge Function accept webhook secret?
3. did Edge recognize meaningful transition?
4. was notification row created?
5. did it find subscriptions?
6. did push service reject endpoint?
7. are public/private VAPID keys from same pair?

---

# 30. Duplicate notifications troubleshooting

Check:

```text
notifications UNIQUE(user_id,event_key)
```

Then confirm Edge code:

```text
creates/claims notification idempotently
sends push only for first creation
```

Webhook retry should not multiply notification rows.

---

# 31. Final secret/location audit

```text
Value                         Local Next   Vercel   Supabase Auth   Edge
----------------------------------------------------------------------------
Supabase URL                  yes          yes
Publishable key               yes          yes
Supabase secret               server       server
App URL                       yes          yes
LinkedIn ID/secret                                    yes
Google ID/secret                                      yes
GitHub ID/secret                                      yes
VAPID public                  yes          yes                       maybe
VAPID private                                                      yes
Webhook secret                                                      yes
Webhook header                                         webhook config
```

A private value in a browser-visible column is a bug.
