# Agent Execution and Handoff Protocol

Use this when orchestrating several code-generation agents.

It supplements, but never replaces, `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md`.

---

# 1. Standard agent prompt wrapper

Prepend this to each specialist agent:

```text
You are implementing one bounded subsystem of an existing project.

Read in order:
1. 00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md
2. <YOUR_SUBSYSTEM_SPEC>.md

00 is the cross-agent source of truth.

Only modify paths explicitly assigned to your subsystem.

Do not rename canonical:
- tables
- columns
- enums
- statuses
- REST routes
- DTO concepts
- query keys
- Storage bucket
- environment variable names
- role model

Do not add Realtime/WebSockets/extra servers.

If you believe a cross-agent contract change is mandatory, do not silently implement it. Write a CONTRACT_CHANGE_REQUEST explaining it.

Before handoff:
- type-check/lint owned code
- run subsystem tests
- list modified files
- list assumptions
- report unresolved core TODOs
- complete the subsystem checklist
```

---

# 2. Recommended order

```text
Human scaffold
    ↓
Database Agent
    ↓
OAuth Agent
    ↓
Backend Agent
    ↓
UI Agent
    ↓
Integration owner
```

Backend and UI may overlap only after `lib/contracts/**` is frozen/stubbed.

---

# 3. Database Agent

Context:

```text
00
01_DATABASE
```

Writes only:

```text
supabase/migrations/**
supabase/seed.sql
lib/types/database.types.ts
```

Publishes:

```text
schema
RLS
Storage policies
generated DB types
```

Must not implement application APIs.

---

# 4. OAuth Agent

Context:

```text
00
03_OAUTH
```

Writes:

```text
app/login/**
app/auth/**
app/post-auth/**
lib/supabase/**
lib/auth/**
proxy.ts
```

Consumes:

```text
profiles
user_roles
```

Publishes reusable:

```text
browser Supabase client
server Supabase client
requireUser
requireStudent
requireCoordinator
```

No downstream agent may create an alternative auth/client stack.

---

# 5. Backend Agent

Context:

```text
00
02_SERVER
```

Writes:

```text
app/api/**
lib/contracts/**
lib/domain/**
lib/server/**
supabase/functions/send-push/**
```

Consumes:

```text
database types
auth guards/client factories
```

Publishes:

```text
API endpoints
DTOs
Zod schemas
domain rules
push contract
```

UI consumes these rather than guessing.

---

# 6. UI Agent

Context:

```text
00
04_UI
```

Writes:

```text
app/student/**
app/coordinator/**
components/**
providers/**
lib/api-client/**
lib/queries/**
lib/ui/**
public/sw.js
```

Consumes:

```text
auth guards
browser Supabase client
API routes
shared DTOs/schemas
push payload contract
```

No backend fallback routes.

---

# 7. Completion report template

Every agent reports:

```text
Owned paths only: yes/no
Canonical names preserved: yes/no
Type/lint clean: yes/no
Relevant tests run: yes/no
Core TODO placeholders remaining: yes/no
Contract change requested: yes/no
```

Also:

```text
Files created:
Files modified:
Assumptions:
Known limitations:
```

---

# 8. Merge-conflict rule

Because ownership is disjoint, a merge conflict between specialist agents usually means an ownership boundary was crossed.

Do not immediately choose `ours`/`theirs`.

Check the ownership map.

---

# 9. Contract change request

Exact format:

```markdown
# CONTRACT_CHANGE_REQUEST

## Requesting subsystem
Backend

## Existing contract
...

## Requested change
...

## Why required
...

## Agents/files affected
Database:
Auth:
Backend:
UI:

## Backward-compatible?
yes/no
```

Integration owner approves/rejects globally.

No unilateral rename.

---

# 10. Context discipline

Do not give every agent the entire repository if not needed.

Each gets:

```text
00 shared context
+ its subsystem spec
+ the exact generated interfaces it consumes
```

Examples:

UI needs:

```text
lib/contracts/**
auth helper signatures
```

It does not need Edge Function internals.

Backend needs:

```text
database.types.ts
auth helper signatures
```

It does not need every UI component.

This reduces accidental duplication.

---

# 11. Integration audit after merge

Check for fallacies/duplication:

1. exactly one Supabase browser-client factory
2. exactly one Supabase server-client factory
3. no `profiles.role`
4. exactly one sealed role source: `user_roles`
5. no student direct INSERT grant into `applications`
6. no UI direct Postgres application insert
7. no PDF bytes through Vercel API
8. no public resume bucket
9. no permanent signed URL storage
10. no Supabase secret key in client bundle
11. no old `linkedin` provider identifier
12. no Realtime imports
13. no WebSocket package
14. polling APIs are no-store
15. query keys match shared contract
16. local mutations invalidate canonical keys
17. status enums match DB/DTO/UI
18. Service Worker PushPayload matches Edge output
19. webhook handler compares old/new
20. event-key idempotency exists
21. database rebuilds from migrations
22. production build passes

---

# 12. Integration smoke test

Use two accounts.

```text
Coordinator:
OAuth login
→ publish drive

Student:
OAuth login
→ receive/see drive
→ apply with resume

Coordinator:
poll applicant list
→ view signed resume
→ shortlist

Student:
poll application status
→ see Shortlisted
```

Also test:

```text
push disabled
```

The workflow must still work because polling + PostgreSQL are independent of push.

---

# 13. Final hackathon demo path

Every subsystem exists to support this explanation:

```text
Identity:
OAuth → Supabase Auth

Authorization:
verified user → sealed user_roles

Workflow:
Next.js Route Handler → PostgreSQL

Documents:
browser → private Storage
coordinator → authorized signed URL

Freshness:
TanStack Query → periodic GET

Background awareness:
DB Webhook → Edge Function → Web Push

Truth:
PostgreSQL
```

If an implementation does not strengthen this path, it is probably outside scope.
