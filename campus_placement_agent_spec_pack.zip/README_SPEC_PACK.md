# Campus Placement Platform — Agent Spec Pack

This pack is meant to be used directly as context/prompt material for code-generation agents.

## How to use it

Every implementation agent receives:

1. `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md`
2. exactly one subsystem spec

Recommended order:

1. Developer follows `05_PROJECT_DIRECTORY_SETUP_GUIDE.md`
2. Database agent gets `01_DATABASE_MIGRATIONS_AND_SCHEMA_SPEC.md`
3. OAuth/session agent gets `03_OAUTH_AND_SESSION_INTEGRATION_SPEC.md`
4. Backend/async agent gets `02_SERVER_ROUTE_HANDLERS_AND_EDGE_FUNCTIONS_SPEC.md`
5. UI agent gets `04_UI_PAGES_AND_CLIENT_BEHAVIOR_SPEC.md`
6. Developer follows `06_API_KEYS_AND_EXTERNAL_INTEGRATIONS_GUIDE.md`
7. Integration owner may also use `07_AGENT_EXECUTION_AND_HANDOFF_PROTOCOL.md`

## Architecture frozen by this pack

- Next.js App Router + TypeScript
- Chakra UI primary; Tailwind only for minor layout/spacing
- TanStack Query for cache and HTTP polling
- Supabase Auth + PostgreSQL + Storage + Database Webhooks + Edge Functions
- LinkedIn OIDC preferred; Google + GitHub alternative OAuth providers
- Vercel deployment
- Web Push + Service Worker for important background notifications
- PostgreSQL is the source of truth
- no Supabase Realtime
- no custom WebSocket server
- no Express/Nest/Fastify
- no Redis, queues, microservices or AI ranking

## Files

| File | Responsibility |
|---|---|
| `00_SHARED_PROJECT_CONTEXT_AND_AGENT_BOUNDARIES.md` | Canonical architecture, names, contracts and agent ownership |
| `01_DATABASE_MIGRATIONS_AND_SCHEMA_SPEC.md` | SQL schema, migrations, constraints, indexes, RLS, Storage policies |
| `02_SERVER_ROUTE_HANDLERS_AND_EDGE_FUNCTIONS_SPEC.md` | Next.js API, business rules, signed URLs, webhook/Edge push pipeline |
| `03_OAUTH_AND_SESSION_INTEGRATION_SPEC.md` | OAuth, SSR Supabase clients, PKCE callback, Proxy, role routing |
| `04_UI_PAGES_AND_CLIENT_BEHAVIOR_SPEC.md` | Student/coordinator pages, query polling, upload UX, Service Worker |
| `05_PROJECT_DIRECTORY_SETUP_GUIDE.md` | From empty folder to running project |
| `06_API_KEYS_AND_EXTERNAL_INTEGRATIONS_GUIDE.md` | Layman setup of keys, OAuth apps, VAPID, Vercel and webhooks |
| `07_AGENT_EXECUTION_AND_HANDOFF_PROTOCOL.md` | Agent orchestration and merge/handoff discipline |

If any subsystem spec conflicts with `00`, `00` wins.
